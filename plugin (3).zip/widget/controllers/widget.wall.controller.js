'use strict';

(function (angular) {
    angular.module('socialPluginWidget')
        .controller('WidgetWallCtrl', ['$scope', 'SocialDataStore', 'Modals', 'Buildfire', "SocialUserProfile", '$rootScope', 'Location', 'EVENTS', 'GROUP_STATUS', 'MORE_MENU_POPUP', 'FILE_UPLOAD', '$modal', 'SocialItems', '$q', '$anchorScroll', '$location', '$timeout', 'Util', 'SubscribedUsersData', function ($scope, SocialDataStore, Modals, Buildfire, SocialUserProfile, $rootScope, Location, EVENTS, GROUP_STATUS, MORE_MENU_POPUP, FILE_UPLOAD, $modal, SocialItems, $q, $anchorScroll, $location, $timeout, util, SubscribedUsersData) {
            var WidgetWall = this;
            WidgetWall.userDetails = {};
            WidgetWall.postText = '';
            WidgetWall.modalPopupThreadId;
            WidgetWall.allowCreateThread = true;
            WidgetWall.allowPrivateChat = false;
            WidgetWall.allowFollowLeaveGroup = true;
            WidgetWall.groupFollowingStatus = false;
            $scope.isBusyLoadingPosts = false;
            WidgetWall.threadTag = "thread";
            WidgetWall.appTheme = null;

            WidgetWall.loadedPlugin = false;
            WidgetWall.SocialItems = SocialItems.getInstance();
            $rootScope.showThread = true;
            WidgetWall.loading = true;

            WidgetWall.showHideCommentBox = function () {
                if (WidgetWall.SocialItems && WidgetWall.SocialItems.appSettings && WidgetWall.SocialItems.appSettings.allowMainThreadTags &&
                    WidgetWall.SocialItems.appSettings.mainThreadUserTags && WidgetWall.SocialItems.appSettings.mainThreadUserTags.length > 0
                ) {
                    var _userTagsObj = WidgetWall.SocialItems.userDetails.userTags;
                    var _userTags = [];
                    if (_userTagsObj) {
                        _userTags = _userTagsObj[Object.keys(_userTagsObj)[0]];
                    }

                    if (_userTags && !WidgetWall.SocialItems.userBanned) {
                        var _hasPermission = false;
                        for (var i = 0; i < WidgetWall.SocialItems.appSettings.mainThreadUserTags.length; i++) {
                            var _mainThreadTag = WidgetWall.SocialItems.appSettings.mainThreadUserTags[i].text;
                            for (var x = 0; x < _userTags.length; x++) {
                                if (_mainThreadTag.toLowerCase() == _userTags[x].tagName.toLowerCase()) {
                                    _hasPermission = true;
                                    break;
                                }
                            }
                        }
                        WidgetWall.allowCreateThread = _hasPermission;
                        if (WidgetWall.SocialItems.userBanned) WidgetWall.allowCreateThread = false;
                    } else {
                        WidgetWall.allowCreateThread = false;
                    }
                } else {
                    if (WidgetWall.SocialItems.userBanned) WidgetWall.allowCreateThread = false;
                    else WidgetWall.allowCreateThread = true;
                }
            };

            WidgetWall.showHidePrivateChat = function () {
                if (WidgetWall.SocialItems && WidgetWall.SocialItems.appSettings && WidgetWall.SocialItems.appSettings.disablePrivateChat) {
                    WidgetWall.allowPrivateChat = false;
                } else {
                    WidgetWall.allowPrivateChat = true;
                }
            };

            WidgetWall.followLeaveGroupPermission = function () {
                if (WidgetWall.SocialItems && WidgetWall.SocialItems.appSettings && WidgetWall.SocialItems.appSettings.disableFollowLeaveGroup) {
                    WidgetWall.allowFollowLeaveGroup = false;
                } else {
                    WidgetWall.allowFollowLeaveGroup = true;
                }
            };

            WidgetWall.formatLanguages = function (strings) {
                Object.keys(strings).forEach(e => {
                    strings[e].value ? WidgetWall.SocialItems.languages[e] = strings[e].value : WidgetWall.SocialItems.languages[e] = strings[e].defaultValue;
                });
            }

            WidgetWall.setSettings = function (settings) {
                WidgetWall.SocialItems.appSettings = settings.data && settings.data.appSettings ? settings.data.appSettings : {};
                WidgetWall.showHidePrivateChat();
                WidgetWall.followLeaveGroupPermission();
                WidgetWall.showHideCommentBox();
                let dldActionItem = new URLSearchParams(window.location.search).get('actionItem');
                if (dldActionItem)
                    WidgetWall.SocialItems.appSettings.actionItem = JSON.parse(dldActionItem);

                let actionItem = WidgetWall.SocialItems.appSettings.actionItem;
                if (actionItem && actionItem.iconUrl) {
                    actionItem.iconUrl = buildfire.imageLib.cropImage(actionItem.iconUrl, { size: 'xss', aspect: '1:1' })
                    angular.element('#actionBtn').attr('style', `background-image: url(${actionItem.iconUrl}) !important; background-size: cover !important;`);
                }

                if (typeof (WidgetWall.SocialItems.appSettings.showMembers) == 'undefined')
                    WidgetWall.SocialItems.appSettings.showMembers = true;
                if (typeof (WidgetWall.SocialItems.appSettings.allowAutoSubscribe) == 'undefined')
                    WidgetWall.SocialItems.appSettings.allowAutoSubscribe = true;
                if (WidgetWall.SocialItems.appSettings && typeof WidgetWall.SocialItems.appSettings.pinnedPost !== 'undefined') {
                    WidgetWall.pinnedPost = WidgetWall.SocialItems.appSettings.pinnedPost;
                    pinnedPost.innerHTML = WidgetWall.pinnedPost;
                }
                WidgetWall.loadedPlugin = true;
                $scope.$digest();

            }

            WidgetWall.setAppTheme = function () {
                buildfire.appearance.getAppTheme((err, obj) => {
                    let elements = document.getElementsByTagName('svg');
                    for (var i = 0; i < elements.length; i++) {
                        elements[i].style.setProperty("fill", obj.colors.icons, "important");
                    }
                    WidgetWall.appTheme = obj.colors;
                    WidgetWall.loadedPlugin = true;
                });
            }

            WidgetWall.getPosts = function () {
                Buildfire.auth.getCurrentUser((err, res) =>{
                    WidgetWall.SocialItems.getPosts( function (err, data) {
                        // WidgetWall.showUserLikes();
                        window.buildfire.messaging.sendMessageToControl({
                            name: 'SEND_POSTS_TO_CP',
                            posts: WidgetWall.SocialItems.items,
                            pinnedPost: WidgetWall.pinnedPost,
                            wid: WidgetWall.SocialItems.wid
                        });
                    });
                });
            }

            // WidgetWall.showUserLikes = function () {
            //     WidgetWall.SocialItems.items.map(item => {
            //         let liked = item.likes.find(like => like === WidgetWall.SocialItems.userDetails.userId);
            //         if (liked) item.isUserLikeActive = true;
            //         else item.isUserLikeActive = false;
            //     });
            //     $scope.$digest();
            // }

            WidgetWall.checkFollowingStatus = function (user = null) {
                WidgetWall.loading = true;
                buildfire.spinner.show();
                SubscribedUsersData.getGroupFollowingStatus(WidgetWall.SocialItems.userDetails.userId, WidgetWall.SocialItems.wid, WidgetWall.SocialItems.context.instanceId, function (err, status) {
                    if (err) console.log('error while getting initial group following status.', err);
                    else {
                        if (!status.length && WidgetWall.SocialItems.appSettings.allowAutoSubscribe) {
                            buildfire.spinner.hide();
                            WidgetWall.loading = false;
                            return WidgetWall.followWall();
                        }
                        if (status.length && !status[0].data.leftWall) {
                            buildfire.notifications.pushNotification.subscribe(
                                {
                                    groupName: WidgetWall.SocialItems.wid === '' ?
                                        WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                                }, () => { });
                            WidgetWall.groupFollowingStatus = true;
                        } else {
                            if (status[0].data.banned) {
                                WidgetWall.SocialItems.userBanned = true;
                                WidgetWall.allowFollowLeaveGroup = false;
                                WidgetWall.allowCreateThread = false;
                                WidgetWall.SocialItems.appSettings.showMembers = false;
                            }
                            WidgetWall.groupFollowingStatus = false;
                        }
                        WidgetWall.showHideCommentBox();
                        if (user) WidgetWall.statusCheck(status, user);
                        buildfire.spinner.hide();
                        WidgetWall.loading = false;
                        $scope.$digest();
                    }
                });
            }

            WidgetWall.unfollowWall = function () {
                SubscribedUsersData.unfollowWall(WidgetWall.SocialItems.userDetails.userId, WidgetWall.SocialItems.wid, false, function (err, result) {
                    if (err) return console.error(err);
                    else {
                        Follows.unfollowPlugin((err, r) => err ? console.log(err) : console.log(r));
                        WidgetWall.groupFollowingStatus = false;
                        buildfire.notifications.pushNotification.unsubscribe(
                            {
                                groupName: WidgetWall.SocialItems.wid === '' ?
                                    WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                            }, () => { });
                        const options = { text: 'You have left this group' };
                        buildfire.components.toast.showToastMessage(options, () => { });
                        $scope.$digest();
                    }
                });
            }

            WidgetWall.followWall = function () {
                let user = WidgetWall.SocialItems.userDetails;
                var params = {
                    userId: user.userId,
                    userDetails: {
                        displayName: user.displayName,
                        firstName: user.firstName,
                        lastName: user.lastName,
                        imageUrl: user.imageUrl,
                        email: user.email,
                        lastUpdated: new Date().getTime(),
                    },
                    wallId: WidgetWall.SocialItems.wid,
                    posts: [],
                    _buildfire: {
                        index: { 
                            text: user.userId + '-' + WidgetWall.SocialItems.wid, string1: WidgetWall.SocialItems.wid 
                        }
                    }
                };
                Follows.followPlugin((e , u) => e ? console.log(e) : console.log(u));

                SubscribedUsersData.save(params, function (err) {
                    if (err) console.log('Error while saving subscribed user data.');
                    else {
                        console.log("here XXXXXXXXX SUBSCRIBED USERS DATA MFERRRR");
                        WidgetWall.groupFollowingStatus = true;
                        buildfire.notifications.pushNotification.subscribe(
                            {
                                groupName: WidgetWall.SocialItems.wid === '' ?
                                WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                            }, () => { });
                        buildfire.spinner.hide();
                        WidgetWall.loading = false;
                        $scope.$digest();
                    }
                });
            }

            WidgetWall.followUnfollow = function () {
                if (WidgetWall.groupFollowingStatus) return WidgetWall.unfollowWall();
                else {
                    WidgetWall.SocialItems.authenticateUser(null, (err, user) => {
                        if (err) return console.error("Getting user failed.", err);
                        if (user) {
                            WidgetWall.loading = true;
                            buildfire.spinner.show();
                            SubscribedUsersData.getGroupFollowingStatus(WidgetWall.SocialItems.userDetails.userId, WidgetWall.SocialItems.wid, WidgetWall.SocialItems.context.instanceId, function (err, status) {
                                if (err) console.log('error while getting initial group following status.', err);
                                else {
                                    if (!status.length) return WidgetWall.followWall();
                                    else if (status.length && status[0].data.leftWall) {
                                        status[0].data.leftWall = false;
                                        Follows.followPlugin((e , u) => e ? console.log(e) : console.log(u));                                        
                                        buildfire.appData.update(status[0].id, status[0].data, 'subscribedUsersData', console.log);
                                        buildfire.notifications.pushNotification.subscribe(
                                            {
                                                groupName: WidgetWall.SocialItems.wid === '' ?
                                                    WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                                            }, () => { });
                                        WidgetWall.groupFollowingStatus = true;
                                    }
                                    else if (status.length && !status[0].data.leftWall)
                                        return WidgetWall.unfollowWall();
                                    WidgetWall.showHideCommentBox();
                                    if (user) WidgetWall.statusCheck(status, user);
                                    buildfire.spinner.hide();
                                    WidgetWall.loading = false;
                                    $scope.$digest();
                                }
                            });
                        }
                    });
                }
            }

            WidgetWall.scheduleNotification = function (post, text) {
                let options = {
                    title: 'Notification',
                    text: '',
                    users: [],
                    sendToSelf: false
                };

                if (text === 'post')
                    options.text = WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' added new post on ' + decodeURI(WidgetWall.SocialItems.context.title);
                else if (text === 'like')
                    options.text = WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' liked a post on ' + decodeURI(WidgetWall.SocialItems.context.title);

                options.inAppMessage = options.text;
                options.queryString = `wid=${WidgetWall.SocialItems.wid}`

                if (text === 'like' && post.userId === WidgetWall.SocialItems.userDetails.userId) return;

                if (WidgetWall.SocialItems.isPrivateChat) {
                    const user1Id = WidgetWall.SocialItems.wid.slice(0, 24);
                    const user2Id = WidgetWall.SocialItems.wid.slice(24, 48);
                    let userToSend = user1Id === WidgetWall.SocialItems.userDetails.userId
                        ? user2Id : user1Id;
                    SubscribedUsersData.getGroupFollowingStatus(userToSend, WidgetWall.SocialItems.wid, WidgetWall.SocialItems.context.instanceId, function (err, status) {
                        if (err) console.error('Error while getting initial group following status.', err);
                        if (status.length && status[0].data && !status[0].data.leftWall) {
                            options.users.push(userToSend);
                            options.text = WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' added new post on '
                                + WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' | ' + WidgetWall.SocialItems.getUserName(status[0].data.userDetails);
                            buildfire.notifications.pushNotification.schedule(options, function (err) {
                                if (err) return console.error('Error while setting PN schedule.', err);
                                console.log("SENT NOTIFICATION", options);
                            });
                        } else if(!status.length && WidgetWall.SocialItems.appSettings.allowAutoSubscribe) {
                            buildfire.auth.getUserProfile({ userId: userToSend }, (err, user) => {
                                if (err) return console.error(err);
                                options.users.push(userToSend);
                                options.text = WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' added new post on '
                                    + WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' | ' + WidgetWall.SocialItems.getUserName(user);
                                buildfire.notifications.pushNotification.schedule(options, function (err) {
                                    if (err) return console.error('Error while setting PN schedule.', err);
                                    console.log("SENT NOTIFICATION", options);
                                });  
                              });
                        }
                    });
                } else {
                    if (text === 'like') {
                        options.users.push(post.userId);
                    }
                    else options.groupName = WidgetWall.SocialItems.wid === '' ?
                        WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                    buildfire.notifications.pushNotification.schedule(options, function (err) {
                        if (err) return console.error('Error while setting PN schedule.', err);
                        console.log("SENT NOTIFICATION", options);
                    });
                }
            }


            WidgetWall.openBottomDrawer = function(userId){
                Follows.isFollowingUser(userId , (err , r) =>{
                        let listItems = [
                            {text:'See Profile'},
                        ];
                        if(WidgetWall.SocialItems.appSettings.allowCommunityFeedFollow == true) listItems.push({text: r ? 'Unfollow' : 'Follow'});
                        if( ( WidgetWall.SocialItems.appSettings && !WidgetWall.SocialItems.appSettings.disablePrivateChat) || WidgetWall.SocialItems.appSettings.disablePrivateChat == false) listItems.push({text:'Send Direct Message'});
                        buildfire.components.drawer.open(
                            {
                                enableFilter:false,
                                listItems: listItems
                            },(err, result) => {
                                if (err) return console.error(err);
                                else if(result.text == "See Profile") buildfire.auth.openProfile(userId);
                                else if(result.text == "Send Direct Message") WidgetWall.openPrivateChat(userId);
                                else if(result.text == "Unfollow") Follows.unfollowUser(userId,(err, r) => err ? console.log(err) : console.log(r));
                                else if(result.text == "Follow") Follows.followUser(userId,(err, r) => err ? console.log(err) : console.log(r));
                                buildfire.components.drawer.closeDrawer();
                            }
                        );
                })
            }

            WidgetWall.openChat = function (userId) {
                if (WidgetWall.allowPrivateChat) {
                    WidgetWall.SocialItems.authenticateUser(null, (err, user) => {
                        if (err) return console.error("Getting user failed.", err);
                        if (user) {
                            buildfire.auth.getUserProfile({ userId: userId }, function (err, user) {
                                if (err) return console.error("Getting user profile failed.", err);
                                if (userId === WidgetWall.SocialItems.userDetails.userId) return;
                                WidgetWall.openPrivateChat(userId, WidgetWall.SocialItems.getUserName(user));
                            });
                        }
                    });
                }
            };

            WidgetWall.init = function () {
                WidgetWall.SocialItems.getSettings((err, result) => {
                    if (err) return console.error("Fetching settings failed.", err);
                    if (result) {
                        console.log("deeplink data hereee");
                        buildfire.deeplink.getData((deeplinkData) => {
                            if (deeplinkData){
                                if(deeplinkData.postId){
                                    
                                    Location.go("#/singlePostView/"+deeplinkData.postId);
                                }
                            }
                        });
                        console.log("deeplink data hereee");
                        let postsContainer = document.getElementById("top");
                        console.log("posts container");
                        console.log(postsContainer);
                        console.log("adding scroll event listener");
                        postsContainer.addEventListener('scroll',() =>{
                            if(!$scope.isBusyLoadingPosts && WidgetWall.SocialItems.showMorePosts && ( postsContainer.scrollTop - (postsContainer.scrollHeight - postsContainer.offsetHeight) > - 30) ){
                                $scope.isBusyLoadingPosts = true;
                                WidgetWall.loadMorePosts((isFinished) =>{
                                    if(isFinished) $scope.isBusyLoadingPosts = false;
                                    $scope.$digest();
                                })
                            }
                        })
                        WidgetWall.SocialItems.items = [];
                        WidgetWall.setSettings(result);
                        WidgetWall.showHidePrivateChat();
                        WidgetWall.followLeaveGroupPermission();
                        WidgetWall.setAppTheme();
                        WidgetWall.getPosts(console.log);

                        WidgetWall.SocialItems.authenticateUser(null, (err, user) => {
                            if (err) return console.error("Getting user failed.", err);
                            if (user) {
                                WidgetWall.checkFollowingStatus(user);
                                WidgetWall.checkForPrivateChat();
                                var params = {
                                    userId: user._id,
                                    interests: [],
                                    isPublicProfile: true,
                                    followers: [],
                                    pendingFollowers: [],
                                    following:[],
                                    _buildfire:{
                                        index:{
                                            string1: user._id
                                        }
                                    }
                                }
                                SocialUserProfile.init(params)
                            } else {
                                WidgetWall.groupFollowingStatus = false;
                            }
                        });
                    }
                });
            };

            WidgetWall.init();


            WidgetWall.goToSinglePostView = (postId) =>{
                Location.go("#/singlePostView/" + postId);
            }

            WidgetWall.checkForPrivateChat = function () {
                if (WidgetWall.SocialItems.isPrivateChat) {  
                        SubscribedUsersData.getUsersWhoFollow(WidgetWall.SocialItems.userDetails.userId, WidgetWall.SocialItems.wid, function (err, users) {
                            if (err) return console.log(err);
                            const user1Id = WidgetWall.SocialItems.wid.slice(0, 24);
                            const user2Id = WidgetWall.SocialItems.wid.slice(24, 48);
                            if (!users.length) {
                                var otherUser = (user1Id.localeCompare(WidgetWall.SocialItems.userDetails.userId) === 0)
                                    ? user2Id : user1Id;
                                WidgetWall.followPrivateWall(otherUser, WidgetWall.SocialItems.wid);
                            }
                        });
                }
            }

            WidgetWall.sanitizeWall = function (callback) {
                buildfire.appData.search(
                    { filter: { '_buildfire.index.string1': WidgetWall.SocialItems.wid } },
                    'subscribedUsersData', function (err, result) {
                        if (err) console.log(err);
                        if (result && result.length > 2) {
                            const user1Id = WidgetWall.SocialItems.wid.slice(0, 24);
                            const user2Id = WidgetWall.SocialItems.wid.slice(24, 48);
                            result.map(item => {
                                if (item.data.userId !== user1Id && item.data.userId !== user2Id) {
                                    buildfire.appData.delete(item.id, 'subscribedUsersData');
                                }
                            });
                        }
                    });
            }

            WidgetWall.followPrivateWall = function (userId, wid, userName = null) {
                buildfire.auth.getUserProfile({ userId: userId }, (err, user) => {
                    if (err) console.log('Error while saving subscribed user data.');
                    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if (re.test(String(user.firstName).toLowerCase()))
                        user.firstName = 'Someone';
                    if (re.test(String(user.displayName).toLowerCase()))
                        user.displayName = 'Someone';

                    var params = {
                        userId: userId,
                        userDetails: {
                            displayName: user.displayName,
                            firstName: user.firstName,
                            lastName: user.lastName,
                            imageUrl: user.imageUrl,
                            email: user.email,
                            lastUpdated: new Date().getTime(),
                        },
                        wallId: wid,
                        posts: [],
                        _buildfire: {
                            index: { text: userId + '-' + wid, string1: wid }
                        }
                    };

                    userName = WidgetWall.SocialItems.getUserName(params.userDetails)
                    SubscribedUsersData.save(params, function (err) {
                        if (err) console.log('Error while saving subscribed user data.');
                        if (userName)
                            WidgetWall.navigateToPrivateChat({ id: userId, name: userName, wid: wid });
                    });
                })
            }

            WidgetWall.navigateToPrivateChat = function (user) {

                WidgetWall.SocialItems.isPrivateChat = true;
                WidgetWall.SocialItems.wid = user.wid;
                WidgetWall.SocialItems.showMorePosts = false;
                WidgetWall.SocialItems.pageSize = 5;
                WidgetWall.SocialItems.page = 0;
                WidgetWall.SocialItems.pluginTitle = WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' | ' + user.name;

                buildfire.history.push(WidgetWall.SocialItems.getUserName(WidgetWall.SocialItems.userDetails) + ' | ' + user.name, {
                    isPrivateChat: true,
                    showLabelInTitlebar: true
                });
                WidgetWall.init();
            }

            $rootScope.$on('loadPrivateChat', function (event, error) {
                WidgetWall.init();
            });

            $rootScope.$on('navigatedBack', function (event, error) {
                WidgetWall.SocialItems.items = [];
                WidgetWall.SocialItems.isPrivateChat = false;
                WidgetWall.SocialItems.pageSize = 5;
                WidgetWall.SocialItems.page = 0;
                WidgetWall.SocialItems.wid = WidgetWall.SocialItems.mainWallID;
                WidgetWall.SocialItems.pluginTitle = '';
                WidgetWall.init();
            });

            WidgetWall.openPrivateChat = function (userId, userName) {
                let wid = null;
                if (WidgetWall.SocialItems.userDetails.userId && WidgetWall.SocialItems.userDetails.userId != userId) {
                    if (WidgetWall.SocialItems.userDetails.userId > userId) {
                        wid = WidgetWall.SocialItems.userDetails.userId + userId;
                    } else {
                        wid = userId + WidgetWall.SocialItems.userDetails.userId;
                    }
                }
                SubscribedUsersData.getGroupFollowingStatus(userId, wid, WidgetWall.SocialItems.context.instanceId, function (err, status) {
                    if (err) console.error('Error while getting initial group following status.', err);
                    if (!status.length) {
                        WidgetWall.followPrivateWall(userId, wid, userName);
                    } else {
                        WidgetWall.navigateToPrivateChat({ id: userId, name: userName, wid: wid });
                    }
                });
            }

            var counter = 0;
            $scope.setupImageList = function (post) {
                if (post.imageUrl) {
                    post.imageListId = "imageList_" + (counter++);
                    setTimeout(function () {
                        let imageList = document.getElementById(post.imageListId);
                        imageList.addEventListener('imageSelected', (e) => {
                            let selectedImage = e.detail.filter(image => image.selected);
                            if (selectedImage && selectedImage[0] && selectedImage[0].name)
                                selectedImage[0].name = selectedImage[0].name;
                            buildfire.imagePreviewer.show({ images: selectedImage });
                        });
                        if (Array.isArray(post.imageUrl)) {
                            imageList.images = post.imageUrl;
                        } else {
                            imageList.images = [post.imageUrl];
                        }

                    }, 0);
                }
            };
            $scope.openThread = function (event, post) {
                if (event.target.nodeName != "BF-IMAGE-LIST")
                    window.location.href = " #/thread/" + post.id;
            };
            WidgetWall.Thread = class {
                constructor(record = {}) {
                    if (!record.data) record.data = {};
                    this.id = record.id || undefined;
                    this.isActive =
                        typeof record.data.isActive === "boolean" ? record.data.isActive : true;
                    this.createdOn = record.data.createdOn || new Date();
                    this.createdBy = record.data.createdBy || undefined;
                    this.lastUpdatedOn = record.data.lastUpdatedOn || undefined;
                    this.lastUpdatedBy = record.data.lastUpdatedBy || undefined;
                    this.deletedOn = record.data.deletedOn || undefined;
                    this.deletedBy = record.data.deletedBy || undefined;

                    this.users = record.data.users || [];
                    this.wallId = record.data.wallId || undefined;
                    this.wallTitle = record.data.wallTitle || undefined;
                    this.navigationData = record.data.navigationData || {
                        pluginId: undefined,
                        instanceId: undefined,
                        folderName: undefined
                    };
                    this.lastMessage = record.data.lastMessage || {
                        text: undefined,
                        createdAt: undefined,
                        sender: undefined,
                        isRead: undefined
                    };
                }

                /**
                 * Get instance ready for data access with _buildfire index object
                 */
                toJSON() {
                    return {
                        id: this.id,
                        isActive: this.isActive,
                        createdOn: this.createdOn,
                        createdBy: this.createdBy,
                        lastUpdatedOn: this.lastUpdatedOn,
                        lastUpdatedBy: this.lastUpdatedBy,
                        deletedOn: this.deletedOn,
                        deletedBy: this.deletedBy,

                        users: this.users,
                        wallId: this.wallId,
                        wallTitle: this.wallTitle,
                        lastMessage: this.lastMessage,
                        navigationData: this.navigationData,
                        _buildfire: {
                            index: {
                                number1: this.isActive ? 1 : 0,
                                date1: this.lastMessage.createdAt,
                                string1: this.wallId,
                                array1: this.users.map(user => ({
                                    string1: user._id
                                })),
                                text: this.users.map(user => user.displayName).join(" || ")
                            }
                        }
                    };
                }
            }

            WidgetWall.verifyWallId = function (user, wallId, callback) {
                if (!wallId || wallId.length != 48)
                    return callback(new Error("Invalid wall id"));

                const user1Id = wallId.slice(0, 24);
                const user2Id = wallId.slice(24, 48);

                if (user._id !== user1Id && user._id !== user2Id)
                    return callback(
                        new Error("Logged in user must be one of the wall users")
                    );

                let users = [];

                const resolve = user => {
                    users.push(user);
                    if (users.length === 2) callback(null, users);
                };

                buildfire.auth.getUserProfile({ userId: user1Id }, (err, user) => {
                    if (err) return callback(err);
                    if (!user) return callback(new Error("User not found"));
                    resolve(user);
                });

                buildfire.auth.getUserProfile({ userId: user2Id }, (err, user) => {
                    if (err) return callback(err);
                    if (!user) return callback(new Error("User not found"));
                    resolve(user);
                });
            }

            WidgetWall.getThread = function (user, wallId, wallTitle, callback) {
                WidgetWall.verifyWallId(user, wallId, (err, users) => {
                    if (err) return callback(err);

                    const filters = {
                        filter: {
                            "_buildfire.index.string1": wallId
                        }
                    };

                    buildfire.appData.search(filters, WidgetWall.threadTag, (err, records) => {
                        if (err) return callback(err);

                        const createdBy = user._id;

                        if (!records || !records.length) {
                            let thread = new WidgetWall.Thread({
                                data: { users, wallId, wallTitle, createdBy }
                            });

                            buildfire.appData.insert(
                                thread.toJSON(),
                                WidgetWall.threadTag,
                                false,
                                (err, record) => {
                                    if (err) return callback(err);
                                    return callback(null, new WidgetWall.Thread(record));
                                }
                            );
                        } else {
                            return callback(null, new WidgetWall.Thread(records[0]));
                        }
                    });
                });
            }


            WidgetWall.getNavigationData = function (callback) {
                Buildfire.pluginInstance.get(WidgetWall.SocialItems.context.instanceId, function (err, plugin) {
                    return callback({
                        pluginId: WidgetWall.SocialItems.context.pluginId,
                        instanceId: plugin.instanceId,
                        folderName: plugin._buildfire.pluginType.result[0].folderName,
                    })
                });
            }

            WidgetWall.onSendMessage = function (user, message, callback) {
                // GET wallId and wallTitle from query params in PSW2
                const wallId = WidgetWall.SocialItems.wid;
                const wallTitle = WidgetWall.SocialItems.pluginTitle;

                WidgetWall.getThread(user, wallId, wallTitle, (err, thread) => {
                    if (err) return callback(err);

                    WidgetWall.getNavigationData(navigationData => {
                        thread.lastUpdatedOn = new Date();
                        thread.lastUpdatedBy = user._id;
                        thread.lastMessage = {
                            text: message,
                            createdAt: new Date(),
                            sender: user._id,
                            isRead: false
                        };
                        thread.navigationData = navigationData;

                        buildfire.appData.update(
                            thread.id,
                            thread.toJSON(),
                            WidgetWall.threadTag,
                            (err, record) => {
                                if (err) return callback(err);
                                return callback(null, new WidgetWall.Thread(record));
                            }
                        );
                    });
                })
            }
            WidgetWall.loadMorePosts = function (callback) {
                WidgetWall.SocialItems.getPosts(function (err, data) {
                    console.log(WidgetWall.SocialItems.items.length);
                    window.buildfire.messaging.sendMessageToControl({
                        name: 'SEND_POSTS_TO_CP',
                        posts: WidgetWall.SocialItems.items,
                        pinnedPost: WidgetWall.pinnedPost,
                        wid: WidgetWall.SocialItems.wid
                    });
                    if(callback){
                        callback(true)
                    }
                });
            }

            function finalPostCreation(imageUrl) {
                let postData = {};
                postData.userDetails = WidgetWall.SocialItems.userDetails;
                postData.images = WidgetWall.images ? $scope.WidgetWall.images : [];
                postData.imageUrl = imageUrl || null;
                postData.videos = WidgetWall.videos ? $scope.WidgetWall.videos : [];
                postData.wid = WidgetWall.SocialItems.wid;
                postData.text = WidgetWall.postText ? WidgetWall.postText.replace(/[#&%+!@^*()-]/g, function (match) {
                    return encodeURIComponent(match)
                }) : '';
                postData.location = WidgetWall.location ? $scope.WidgetWall.location : {};
                postData.taggedPeople = WidgetWall.taggedPeople ? $scope.WidgetWall.taggedPeople : [];
                postData.originalPostId = WidgetWall.originalPostId ? $scope.WidgetWall.originalPostId : "";
                WidgetWall.onSendMessage({ _id: postData.userDetails && postData.userDetails.userId ? postData.userDetails.userId : null }, postData.text, () =>
                    SocialDataStore.createPost(postData).then((response) => {
                        WidgetWall.SocialItems.items.unshift(postData);
                        Buildfire.messaging.sendMessageToControl({
                            name: EVENTS.POST_CREATED,
                            status: 'Success',
                            post: response.data
                        });
                        postData.id = response.data.id;
                        postData.uniqueLink = response.data.uniqueLink;
                        WidgetWall.scheduleNotification(postData, 'post');
                        // window.scrollTo(0, 0);
                        // $location.hash('top');
                        // $anchorScroll();
                    }, (err) => {
                        console.error("Something went wrong.", err)
                        WidgetWall.postText = '';
                    })
                );
            }

            WidgetWall.getPostContent = function (data) {
                if (data && data.results && data.results.length > 0 && !data.cancelled) {
                    $scope.WidgetWall.postText = data.results["0"].textValue;
                    $scope.WidgetWall.images = data.results["0"].images;

                    var gif = getGifUrl(data.results["0"].gifs);
                    if (gif && $scope.WidgetWall.images && $scope.WidgetWall.images.push) {
                        $scope.WidgetWall.images.push(gif);
                    }
                    function getGifUrl(gifs) {
                        if (gifs["0"] && gifs["0"].images.downsided_medium && gifs["0"].images.downsided_medium.url) {
                            return gifs["0"].images.downsided_medium.url;
                        } else if (gifs["0"] && gifs["0"].images.original && gifs["0"].images.original.url) {
                            return gifs["0"].images.original.url;
                        }
                    }
                }
            }

            WidgetWall.openPostSection = function(){
                console.log("here");
                Location.go('#/post/createPost');
            }

            // WidgetWall.openPostSection = function () {
            //     WidgetWall.SocialItems.authenticateUser(null, (err, user) => {
            //         if (err) return console.error("Getting user failed.", err);
            //         if (user) {
            //             WidgetWall.checkFollowingStatus();
                        // buildfire.input.showTextDialog({
                        //     "placeholder": WidgetWall.SocialItems.languages.writePost,
                        //     "saveText": WidgetWall.SocialItems.languages.confirmPost.length > 9 ? WidgetWall.SocialItems.languages.confirmPost.substring(0, 9) : WidgetWall.SocialItems.languages.confirmPost,
                        //     "cancelText": WidgetWall.SocialItems.languages.cancelPost.length > 9 ? WidgetWall.SocialItems.languages.cancelPost.substring(0, 9) : WidgetWall.SocialItems.languages.cancelPost,
                        //     "attachments": {
                        //         "images": { enable: true, multiple: true },
                        //         "gifs": { enable: true }
                        //     }
                        // }, (err, data) => {
            //                 if (err) return console.error("Something went wrong.", err);
            //                 if (data.cancelled) return console.error('User canceled.')
            //                 WidgetWall.getPostContent(data);
            //                 if ((WidgetWall.postText || ($scope.WidgetWall.images && $scope.WidgetWall.images.length > 0))) {
            //                     finalPostCreation($scope.WidgetWall.images);
            //                     if(!WidgetWall.SocialItems.isPrivateChat){
            //                         buildfire.auth.getCurrentUser((err , currentUser) => {
            //                             if(err || !currentUser) return;
            //                             else{
            //                                 console.log(WidgetWall.postText);
            //                                 Posts.addPost({postText:WidgetWall.postText ? WidgetWall.postText : "", postImages:$scope.WidgetWall.images || []},(err, r) => err ? console.log(err) : console.log(r));
            //                             } 
            //                         })
            //                     }
            //                 }
            //             });
            //         }
            //     });
            // }

            WidgetWall.navigateTo = function () {
                let privacy = util.getParameterByName("privacy") ? util.getParameterByName("privacy") : null;
                let query = 'wid=' + WidgetWall.SocialItems.wid;
                if (privacy) query += '&privacy=' + privacy;
                if (!WidgetWall.SocialItems.appSettings.actionItem.queryString)
                    WidgetWall.SocialItems.appSettings.actionItem.queryString = query;
                if (WidgetWall.SocialItems.appSettings.actionItem.type === 'navigation') {
                    Buildfire.navigation.navigateTo({
                        pluginId: WidgetWall.SocialItems.appSettings.actionItem.pluginId,
                        queryString: WidgetWall.SocialItems.appSettings.actionItem.queryString
                    });
                } else {
                    buildfire.actionItems.execute(WidgetWall.SocialItems.appSettings.actionItem, (err, action) => {
                        if (err) return console.error(err);
                    });
                }
            }

            WidgetWall.showMembers = function () {
                WidgetWall.SocialItems.authenticateUser(null, (err, userData) => {
                    if (err) return console.error("Getting user failed.", err);

                    if (userData) {
                        if (WidgetWall.SocialItems.wid) {
                            Location.go('#/members/' + WidgetWall.SocialItems.wid);
                        } else {
                            Location.go('#/members/home');
                        }
                    }
                });

            }

            WidgetWall.showMoreOptions = function (post) {
                WidgetWall.modalPopupThreadId = post.id;
                WidgetWall.SocialItems.authenticateUser(null, (err, userData) => {
                    if (err) return console.error("Getting user failed.", err);
                    if (userData) {
                        WidgetWall.checkFollowingStatus();
                        Modals.showMoreOptionsModal({
                            'postId': post.id,
                            'userId': post.userId,
                            'socialItemUserId': WidgetWall.SocialItems.userDetails.userId,
                            'languages': WidgetWall.SocialItems.languages
                        })
                            .then(function (data) {
                                if (WidgetWall.SocialItems.userBanned) return;
                                switch (data) {
                                    case WidgetWall.SocialItems.languages.reportPost:
                                        SocialDataStore.reportPost({
                                            reportedAt: new Date(),
                                            reporter: WidgetWall.SocialItems.userDetails.email,
                                            reported: post.userDetails.email,
                                            reportedUserID: post.userId,
                                            text: post.text,
                                            postId: post.id,
                                            wid: WidgetWall.SocialItems.wid
                                        });
                                        break;
                                    case "delete":
                                        WidgetWall.deletePost(post.id);
                                        break;
                                    case MORE_MENU_POPUP.BLOCK:

                                        $modal
                                            .open({
                                                templateUrl: 'templates/modals/delete-post-modal.html',
                                                controller: 'MoreOptionsModalPopupCtrl',
                                                controllerAs: 'MoreOptionsPopup',
                                                size: 'sm',
                                                resolve: {
                                                    Info: function () {
                                                        return post.id;
                                                    }
                                                }
                                            });
                                        break;
                                    default:
                                }

                            },
                                function (err) {
                                    console.log('Error in Error handler--------------------------', err);
                                });
                    }
                });
            };


            WidgetWall.sharePost = function(post){
                console.log(post);
                Buildfire.deeplink.generateUrl({
                    data: {postId: post.id}
                }, function (err, result) {
                    if (err) {
                        console.error(err)
                    } else {
                        buildfire.device.share({
                            text: "Hey Check out this post:",
                            image: post.images.length > 0 ? post.images[0] : null,
                            link: result.url
                        }, function (err, result) { });

                    }
                });
            }


            WidgetWall.repostPost = function(post){
                Buildfire.input.showTextDialog({
                    "placeholder": "Enter a caption to repost",
                    "defaultValue": "",
                    "attachments": {
                        "images": { enable: false },
                        "gifs": { enable: false }
                    }
                }, (err, data) => {
                    if(err || !data || !data.results || !data.results.length > 0) return;
                    let text = data.results[0].textValue;
                    let postData = {
                        text: text ? text.replace(/[#&%+!@^*()-]/g, function (match) {
                            return encodeURIComponent(match)
                        }) : '',
                        images : post.images,
                        videos : post.videos,
                        location: post.location,
                        taggedPeople: [],
                        hashtags: [],
                        userDetails: WidgetWall.SocialItems.userDetails,
                        wid: WidgetWall.SocialItems.wid,
                        originalAuthorName: WidgetWall.SocialItems.getUserName(post.userDetails),
                    }
                    SocialDataStore.createPost(postData).then((response) => {
                        console.log("RESPONSE HERE ####");
                        console.log(response);
                        console.log("RESPONSE HERE ####");
                        WidgetWall.SocialItems.items.unshift(postData);
                            Buildfire.messaging.sendMessageToControl({
                                name: EVENTS.POST_CREATED,
                                status: 'Success',
                                post: response.data
                            });
                            postData.id = response.data.id;
                            postData.uniqueLink = response.data.uniqueLink;
                            
    
                        }, (err) => {
                            console.error("Something went wrong.", err)
                            $scope.text = '';
                        })
                });
                
            }


            WidgetWall.likeThread = function (post) {
                WidgetWall.SocialItems.authenticateUser(null, (err, userData) => {
                    if (err) return console.error("Getting user failed.", err);
                    if (userData) {
                        if (WidgetWall.SocialItems.userBanned) return;
                        let liked = post.likes.find(element => element === WidgetWall.SocialItems.userDetails.userId);
                        let index = post.likes.indexOf(WidgetWall.SocialItems.userDetails.userId)
                        let postUpdate = WidgetWall.SocialItems.items.find(element => element.id === post.id)
                        if (liked !== undefined) {
                            post.likes.splice(index, 1)
                            postUpdate.isUserLikeActive = false;
                            Buildfire.messaging.sendMessageToControl({
                                'name': EVENTS.POST_UNLIKED,
                                'id': postUpdate.id,
                                'userId': liked
                            });
                        }
                        else {
                            post.likes.push(WidgetWall.SocialItems.userDetails.userId);
                            postUpdate.isUserLikeActive = true;
                            Buildfire.messaging.sendMessageToControl({
                                'name': EVENTS.POST_LIKED,
                                'id': postUpdate.id,
                                'userId': liked
                            });
                        }
                        SocialDataStore.updatePost(post).then(() => {
                            SubscribedUsersData.getGroupFollowingStatus(post.userId, WidgetWall.SocialItems.wid, WidgetWall.SocialItems.context.instanceId, function (err, status) {
                                if (status.length &&
                                    status[0].data && !status[0].data.leftWall && !liked) WidgetWall.scheduleNotification(post, 'like');
                            });
                        }, (err) => console.log(err));
                    }
                });
            }

            WidgetWall.seeMore = function (post) {
                post.seeMore = true;
                post.limit = 10000000;
                if (!$scope.$$phase) $scope.$digest();
            };

            WidgetWall.getDuration = function (timestamp) {
                if (timestamp)
                    return moment(timestamp.toString()).fromNow();
            };

            WidgetWall.goInToThread = function (threadId) {

                WidgetWall.SocialItems.authenticateUser(null, (err, user) => {
                    if (err) return console.error("Getting user failed.", err);
                    if (user) {
                        WidgetWall.checkFollowingStatus();
                        if (threadId && !WidgetWall.SocialItems.userBanned)
                            Location.go('#/thread/' + threadId);
                    }
                });
            };

            WidgetWall.deletePost = function (postId) {
                var success = function (response) {
                    if (response) {
                        Buildfire.messaging.sendMessageToControl({ 'name': EVENTS.POST_DELETED, 'id': postId });
                        let postToDelete = WidgetWall.SocialItems.items.find(element => element.id === postId)
                        console.log(postToDelete);
                        Posts.deletePost({userId:postToDelete.userId,postText:postToDelete.text,postImages: postToDelete.imageUrl || [],},(err, r) =>{return});
                        let index = WidgetWall.SocialItems.items.indexOf(postToDelete);
                        WidgetWall.SocialItems.items.splice(index, 1);
                        if (!$scope.$$phase)
                            $scope.$digest();
                    }
                };
                // Called when getting error from SocialDataStore.deletePost method
                var error = function (err) {
                    console.log('Error while deleting post ', err);
                };
                // Deleting post having id as postId
                SocialDataStore.deletePost(postId).then(success, error);
            };

            Buildfire.messaging.onReceivedMessage = function (event) {
                if (event) {
                    switch (event.name) {
                        case EVENTS.POST_DELETED:
                            WidgetWall.SocialItems.items = WidgetWall.SocialItems.items.filter(function (el) {
                                return el.id != event.id;
                            });

                            if (WidgetWall.modalPopupThreadId == event.id)
                                Modals.close('Post already deleted');
                            if (!$scope.$$phase)
                                $scope.$digest();
                            break;
                        case EVENTS.BAN_USER:
                            delete event.name;
                            SubscribedUsersData.unfollowWall(event.reported, event.wid, true, function (err, result) {
                                if (err) return console.error(err);
                                else {
                                    WidgetWall.SocialItems.items = WidgetWall.SocialItems.items.filter(function (el) {
                                        return el.userId !== event.reported;
                                    });
                                    WidgetWall.SocialItems.items.map(item => {
                                        item.comments.filter(function (el) {
                                            return el.userId !== event.reported;
                                        });
                                    });
                                    if (!$scope.$$phase)
                                        $scope.$digest();
                                }
                            });

                            break;
                        case EVENTS.COMMENT_DELETED:
                            let post = WidgetWall.SocialItems.items.find(element => element.id === event.postId)
                            let index = post.comments.indexOf(event.comment);
                            post.comments.splice(index, 1);
                            if (WidgetWall.modalPopupThreadId == event.postId)
                                Modals.close('Comment already deleted');
                            if (!$scope.$$phase)
                                $scope.$digest();
                            break;
                        case 'ASK_FOR_POSTS':
                            if (WidgetWall.SocialItems.items.length) {
                                window.buildfire.messaging.sendMessageToControl({
                                    name: 'SEND_POSTS_TO_CP',
                                    posts: WidgetWall.SocialItems.items,
                                    pinnedPost: WidgetWall.pinnedPost
                                });
                            }
                            break;
                        case 'ASK_FOR_WALLID':
                            window.buildfire.messaging.sendMessageToControl({
                                name: 'SEND_WALLID',
                                wid: WidgetWall.SocialItems.wid,
                            });
                        default:
                            break;
                    }
                }
            };

            WidgetWall.decodeText = function (text) {
                return decodeURIComponent(text);
            };

            Buildfire.datastore.onUpdate(function (response) {
                if (response.tag === "Social") {
                    WidgetWall.setSettings(response);
                    setTimeout(function () {
                        if (!response.data.appSettings.disableFollowLeaveGroup) {
                            let wallSVG = document.getElementById("WidgetWallSvg")
                            if (wallSVG) {
                                wallSVG.style.setProperty("fill", WidgetWall.appTheme.icons, "important");
                            }
                        }
                    }, 100);
                }
                else if (response.tag === "languages")
                    WidgetWall.SocialItems.formatLanguages(response);
                $scope.$digest();
            });

            function updatePostsWithNames(user, status) {
                let page = 0, pageSize = 50, allPosts = [];
                function get() {
                    buildfire.appData.search({
                        filter: {
                            $or: [
                                { "$json.userId": user._id },
                                { "$json.comments.userId": user._id },
                            ]
                        }, page, pageSize, recordCount: true
                    }, 'wall_posts', (err, posts) => {
                        allPosts = allPosts.concat(posts.result);
                        if (posts.totalRecord > allPosts.length) {
                            page++;
                            get();
                        } else {
                            allPosts.map(item => {
                                var needsUpdate = false;
                                if (item.data.userId === user._id) {
                                    item.data.userDetails = status[0].data.userDetails;
                                    needsUpdate = true;
                                }
                                item.data.comments.map(comment => {
                                    if (comment.userId === user._id) {
                                        comment.userDetails = status[0].data.userDetails;
                                        needsUpdate = true;
                                    }
                                });
                                if (needsUpdate) {
                                    let postUpdate = WidgetWall.SocialItems.items.find(post => post.id === item.id);
                                    if (postUpdate) {
                                        let postIndex = WidgetWall.SocialItems.items.indexOf(postUpdate);
                                        WidgetWall.SocialItems.items[postIndex] = item.data;
                                    }
                                    buildfire.appData.update(item.id, item.data, 'wall_posts', (err, updatedPost) => {
                                        console.log(updatedPost)
                                        if (!$scope.$$phase) $scope.$digest();

                                    });
                                }

                            })
                            if (!$scope.$$phase) $scope.$digest();
                        }
                    });
                }
                get();
            }

            WidgetWall.statusCheck = function (status, user) {
                if (status && status[0]) {
                    if (!status[0].data.userDetails.lastUpdated) {
                        status[0].data.userDetails.lastUpdated = user.lastUpdated;
                        window.buildfire.appData.update(status[0].id, status[0].data, 'subscribedUsersData', function (err, data) {
                            if (err) return console.error(err);
                        });
                    } else {
                        var lastUpdated = new Date(status[0].data.userDetails.lastUpdated).getTime();
                        var dbLastUpdate = new Date(user.lastUpdated).getTime();
                        if (dbLastUpdate > lastUpdated || (typeof status[0].data.userDetails.firstName === 'undefined'
                            || typeof status[0].data.userDetails.lastName === 'undefined')) {
                            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                            if (re.test(String(user.firstName).toLowerCase()))
                                user.firstName = 'Someone';
                            if (re.test(String(user.displayName).toLowerCase()))
                                user.displayName = 'Someone';
                            status[0].data.userDetails.displayName = user.displayName ? user.displayName : "";
                            status[0].data.userDetails.firstName = user.firstName ? user.firstName : "";
                            status[0].data.userDetails.lastName = user.lastName ? user.lastName : "";
                            status[0].data.userDetails.email = user.email;
                            status[0].data.userDetails.imageUrl = user.imageUrl;
                            status[0].data.userDetails.lastUpdated = user.lastUpdated;

                            window.buildfire.appData.update(status[0].id, status[0].data, 'subscribedUsersData', function (err, data) {
                                if (err) return console.error(err);
                                updatePostsWithNames(user, status);
                            });

                        }
                    }
                }
            }

            WidgetWall.privateChatSecurity = function () {
                if (WidgetWall.SocialItems.isPrivateChat) {
                    const user1Id = WidgetWall.SocialItems.wid.slice(0, 24);
                    const user2Id = WidgetWall.SocialItems.wid.slice(24, 48);
                    var loggedUser = WidgetWall.SocialItems.userDetails.userId;

                    if (loggedUser !== user1Id && loggedUser !== user2Id) {
                        buildfire.history.get({
                            pluginBreadcrumbsOnly: true
                        }, function (err, result) {
                            if (result[result.length - 1].options.isPrivateChat) {
                                result.map(item => buildfire.history.pop());
                                WidgetWall.SocialItems.items = [];
                                WidgetWall.SocialItems.isPrivateChat = false;
                                WidgetWall.SocialItems.pageSize = 5;
                                WidgetWall.SocialItems.page = 0;
                                WidgetWall.SocialItems.wid = WidgetWall.SocialItems.mainWallID;
                                WidgetWall.init();
                            }
                        });

                    }
                }
            }
            WidgetWall.navigateToProfile = function(userId){
                Location.go("#/profile/"+userId);
            }
            WidgetWall.showMainWall = function(){
                Location.go("");
            }
            WidgetWall.goToMyProfile = function(){
                var userId = WidgetWall.SocialItems.userDetails.userId;
                console.log(WidgetWall);
                if(!userId) return;
                Location.go("#/profile/"+userId);
            }
            WidgetWall.goToDiscover = function(){
                Location.go("#/discover/");
                // Location.go("#/search")
                // Location.go("#//post/createPost")
            }
            WidgetWall.openImageInFullScreen = (src) =>{
                buildfire.imagePreviewer.show(
                    {
                      images: [src],
                    },
                    () => {
                      console.log("Image previewer closed");
                    }
                  );
            }
            // On Login
            Buildfire.auth.onLogin(function (user) {
                console.log("NEW USER LOGGED IN", WidgetWall.SocialItems.forcedToLogin)
                if (!WidgetWall.SocialItems.forcedToLogin) {
                    WidgetWall.SocialItems.authenticateUser(user, (err, userData) => {
                        if (err) return console.error("Getting user failed.", err);
                        if (userData) {
                            WidgetWall.checkFollowingStatus();
                            WidgetWall.SocialItems.items = [];
                            WidgetWall.getPosts(console.log);
                        }
                    });
                } else WidgetWall.SocialItems.forcedToLogin = false;
                // WidgetWall.showUserLikes();
                if ($scope.$$phase) $scope.$digest();
            });
            // On Logout
            Buildfire.auth.onLogout(function () {
                console.log('User loggedOut from Widget Wall Page');
                buildfire.appearance.titlebar.show();
                WidgetWall.SocialItems.userDetails = {};
                WidgetWall.groupFollowingStatus = false;
                buildfire.notifications.pushNotification.unsubscribe(
                    {
                        groupName: WidgetWall.SocialItems.wid === '' ?
                            WidgetWall.SocialItems.context.instanceId : WidgetWall.SocialItems.wid
                    }, () => { });
                WidgetWall.privateChatSecurity();
                $scope.$digest();
            });
            setTimeout(() => {           
            }, 10);
            // WidgetWall.goToDiscover();
        }])
})(window.angular);

// <!DOCTYPE html><html lang="en" ng-app="socialPluginWidget">
//     <head>
//         <meta name="buildfire" content="disableFastClick,disableSelect">
//         <link rel="stylesheet" href="styles.min.css?v=1643048475181">
//         <script src="../../../scripts/jquery/jquery-1.11.2.min.js">
//         </script>
//         <script src="../../../scripts/buildfire.js">

//         </script>
//         <script src="../../../scripts/buildfire/components/drawer/drawer.js">

//         </script>
//         <script src="../../../scripts/angular/angular.min.js"></script>
//         <script src="../../../scripts/angular/angular-route.min.js"></script>
//         <script src="../../../scripts/buildfire/services/publicFiles/publicFiles.js"></script>
//         <script src="../../../scripts/angular/ui-bootstrap.min.js"></script>
//         <script src="../../../scripts/angular/angular-animate.min.js"></script>
//         <script src="./assets/js/shared/autoComplete/autoComplete.js"></script>
//         <script src="./assets/js/shared/hashtags/hashtags.js"></script>
//         <script src="../../../scripts/buildfire/services/camera/camera.js">

//         </script>
//    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&key=AIzaSyC4Dw4EzKeyVBXWBsbO9-UgyEARL6WLrlU"></script>
//         <script src="./CommunityFeed/cfScripts.min.js?v=1643048475181"></script>
//         <script src="scripts.min.js?v=1643048475181"></script><script>moment().format();</script>
//         <meta charset="utf-8"></head>
        
        
//         <body id="test"><div class="main_view"><div class="slide-right main-thread-section" ng-show="showThread" ng-controller="WidgetWallCtrl as WidgetWall" ng-cloak><div class="backgroundColorTheme content"><div class="padding-zero" style="height: 100%;"><div class="social-plugin social-wall"><div ng-class="{'has-comment-box':WidgetWall.SocialItems.userDetails.userId == null || WidgetWall.allowCreateThread,'has-group-header' : WidgetWall.allowFollowLeaveGroup}" class="post-section backgroundColorTheme"><div class="post-infinite-scroll" id="top"><div><div class="head" ng-show="WidgetWall.pinnedPost && !WidgetWall.SocialItems.isPrivateChat" id="pinnedPost" style="height: 100%;"></div></div><div ng-show="WidgetWall.SocialItems.items.length<=0 && WidgetWall.loadedPlugin && !WidgetWall.loading"><div class="empty_state"></div></div><div class="social-item" ng-repeat="post in WidgetWall.SocialItems.items"><div class="head"><div ng-class="{'social-profile-user-photo': WidgetWall.SocialItems.userDetails.userId == post.userId}" class="social-profile-photo"><div ng-if="WidgetWall.SocialItems.userDetails.userId == post.userId" class="social-profile-photo"><div ng-class="{'social-copy-user': WidgetWall.SocialItems.userDetails.userId == post.userId}" class="social-copy"><p class="text-primary ellipsis"><a class="ng-cloak" ng-click="WidgetWall.openChat(post.userId)">{{WidgetWall.SocialItems.getUserName(post.userDetails)}}</a></p><div ng-if="post.createdOn"><p class="time-ago opacity-seventy ng-cloak">{{WidgetWall.getDuration(post.createdOn) | convertTimeFormat}}</p></div></div></div><div class="media-holder ng-cloak"><img ng-if="post.userId && post.userDetails.imageUrl" load-image="1x1" data-final-src="{{post.userDetails.imageUrl}}" crop-width="40" crop-height="40" crop-type="crop"> <img ng-if="!(post.userId && post.userDetails.imageUrl)" load-image="1x1" data-final-src="../../../styles/media/avatar-placeholder.png" data-img-type="local" crop-width="40" crop-height="40" crop-type="default"></div><div ng-if="WidgetWall.SocialItems.userDetails.userId != post.userId" class="social-profile-photo"><div class="social-copy"><p class="text-primary ellipsis"><a class="ng-cloak" ng-click="WidgetWall.openBottomDrawer(post.userId)">{{WidgetWall.SocialItems.getUserName(post.userDetails)}}</a></p><div ng-if="post.createdOn"><p class="time-ago opacity-seventy ng-cloak">{{WidgetWall.getDuration(post.createdOn) | convertTimeFormat}}</p></div></div></div></div></div><div ng-class="{'post-text-user': WidgetWall.SocialItems.userDetails.userId == post.userId}" class="post-text copy"><p class="cursor-pointer"><span ng-click=" (!WidgetWall.SocialItems.isPrivateChat) ? WidgetWall.goInToThread(post.id) : WidgetWall.goInToThread(post.id)" ng-bind-html="(WidgetWall.decodeText(post.text) | limitTo : (post.limit || 150) :0) | newLine"></span> <span ng-if="(post.text.trim().length>150 && !post.seeMore)" class="ng-cloak">...</span> <a ng-if="(post.text.trim().length>150 && !post.seeMore)" ng-click="WidgetWall.seeMore(post)" class="text-info ng-cloak">Read More</a></p></div><div class="plugin-banner"><div class="plugin-slide text-center" style="max-height: none !important;"><a ng-click="openThread($event,post)" ng-init="setupImageList(post)"><bf-image-list ng-if="post.imageListId" id="{{post.imageListId}}" token="czi3m2qn"></bf-image-list></a></div></div><div ng-show="post.userId" class="footer clearfix"><div class="status"><div class="status-footer"><div class="footer-item"><a class="social-icon ng-cloak" ng-click="WidgetWall.likeThread(post)"><i class="material-icons-outlined" ng-class="{notActive: !post.isUserLikeActive }" aria-hidden="true">thumb_up_off_alt</i></a></div><div class="footer-item" ng-click="WidgetWall.repostPost(post.originalPostId || post.id)"><a class="social-icon ng-cloak"><span class="material-icons-outlined">repeat</span></a></div><div class="footer-item" ng-click="WidgetWall.sharePost(post)"><a class="social-icon ng-cloak"><span class="material-icons-outlined">share</span></a></div><div class="footer-item"></div></div></div></div></div><div class="loadMorePosts" ng-show="WidgetWall.SocialItems.showMorePosts" ng-click="WidgetWall.loadMorePosts()"><button><a>Show More</a></button></div></div></div></div></div></div><div class="holder padding-zero bottom-post" ng-class="full-post-section"><div class="small-post-box" ng-submit="" handle-phone-submit><div class="post-holder"><div id="actionBtn" ng-show="WidgetWall.SocialItems.appSettings.actionItem" class="add-message btn btn--act btn--add btn-primary" ng-click="WidgetWall.navigateTo()" on-touchend="WidgetWall.navigateTo()"><svg ng-show="!WidgetWall.SocialItems.appSettings.actionItem.iconUrl" class="svgIcon" viewBox="0 0 24 24" aria-hidden="true" height="32px" width="32px" version="1.1"><path d="M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z"></path></svg></div><button ng-show="WidgetWall.allowCreateThread && WidgetWall.loadedPlugin" class="add-message btn btn--fab btn--add btn-primary" id="addBtn" ng-click="WidgetWall.openPostSection()" on-touchend="WidgetWall.openPostSection()"><svg class="svgIcon" height="16px" width="16px" version="1.1" viewBox="0 0 16 16" x="0px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" y="0px"><path d="M11,8.3L2.6,8.8C2.4,8.8,2.3,8.9,2.3,9l-1.2,4.1c-0.2,0.5,0,1.1,0.4,1.5C1.7,14.9,2,15,2.4,15c0.2,0,0.4,0,0.6-0.1l11.2-5.6 C14.8,9,15.1,8.4,15,7.8c-0.1-0.4-0.4-0.8-0.8-1L3,1.1C2.5,0.9,1.9,1,1.5,1.3C1,1.7,0.9,2.3,1.1,2.9L2.3,7c0,0.1,0.2,0.2,0.3,0.2 L11,7.7c0,0,0.3,0,0.3,0.3S11,8.3,11,8.3z"></path></svg></button></div></div></div></div><div class="slide-left side-thread-section" ng-view="" ng-hide="showThread"><h5 class="titleBarTheme text-center" style="margin-top: 35px;">Something went wrong!! Please try again</h5></div></div><script>buildfire.appearance.titlebar.show();</script><script src="../../../scripts/buildfire/components/web-components/buildfire-components.js"></script><script src="../../../scripts/buildfire/services/notifications/pushNotifications.js"></script><script src="../../../scripts/buildfire/components/toast/toast.js"></script></body></html>