/**
 * Tagify (v 4.9.8) - tags input component
 * By Yair Even-Or
 * Don't sell this code. (c)
 * https://github.com/yairEO/tagify
 */

!(function (t, e) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = e())
    : "function" == typeof define && define.amd
    ? define(e)
    : ((t = "undefined" != typeof globalThis ? globalThis : t || self).Tagify =
        e());
})(this, function () {
  "use strict";
  function t(t, e) {
    var i = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
      var s = Object.getOwnPropertySymbols(t);
      e &&
        (s = s.filter(function (e) {
          return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })),
        i.push.apply(i, s);
    }
    return i;
  }
  function e(e) {
    for (var s = 1; s < arguments.length; s++) {
      var a = null != arguments[s] ? arguments[s] : {};
      s % 2
        ? t(Object(a), !0).forEach(function (t) {
            i(e, t, a[t]);
          })
        : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a))
        : t(Object(a)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t));
          });
    }
    return e;
  }
  function i(t, e, i) {
    return (
      e in t
        ? Object.defineProperty(t, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0,
          })
        : (t[e] = i),
      t
    );
  }
  const s = (t, e, i, s) => (
    (t = "" + t),
    (e = "" + e),
    s && ((t = t.trim()), (e = e.trim())),
    i ? t == e : t.toLowerCase() == e.toLowerCase()
  );
  function a(t, e) {
    var i,
      s = {};
    for (i in t) e.indexOf(i) < 0 && (s[i] = t[i]);
    return s;
  }
  function n(t) {
    var e = document.createElement("div");
    return t.replace(/\&#?[0-9a-z]+;/gi, function (t) {
      return (e.innerHTML = t), e.innerText;
    });
  }
  function o(t, e) {
    for (e = e || "previous"; (t = t[e + "Sibling"]); )
      if (3 == t.nodeType) return t;
  }
  function r(t) {
    return "string" == typeof t
      ? t
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/`|'/g, "&#039;")
      : t;
  }
  function l(t) {
    var e = Object.prototype.toString.call(t).split(" ")[1].slice(0, -1);
    return (
      t === Object(t) &&
      "Array" != e &&
      "Function" != e &&
      "RegExp" != e &&
      "HTMLUnknownElement" != e
    );
  }
  function d(t, e, i) {
    function s(t, e) {
      for (var i in e)
        if (e.hasOwnProperty(i)) {
          if (l(e[i])) {
            l(t[i]) ? s(t[i], e[i]) : (t[i] = Object.assign({}, e[i]));
            continue;
          }
          if (Array.isArray(e[i])) {
            t[i] = Object.assign([], e[i]);
            continue;
          }
          t[i] = e[i];
        }
    }
    return t instanceof Object || (t = {}), s(t, e), i && s(t, i), t;
  }
  function h(t) {
    return String.prototype.normalize
      ? "string" == typeof t
        ? t.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        : void 0
      : t;
  }
  var g = () => /(?=.*chrome)(?=.*android)/i.test(navigator.userAgent);
  function c(t) {
    return (
      t && t.classList && t.classList.contains(this.settings.classNames.tag)
    );
  }
  var p = {
    delimiters: ",",
    pattern: null,
    tagTextProp: "value",
    maxTags: 1 / 0,
    callbacks: {},
    addTagOnBlur: !0,
    duplicates: !1,
    whitelist: [],
    blacklist: [],
    enforceWhitelist: !1,
    userInput: !0,
    keepInvalidTags: !1,
    mixTagsAllowedAfter: /,|\.|\:|\s/,
    mixTagsInterpolator: ["[[", "]]"],
    backspace: !0,
    skipInvalid: !1,
    pasteAsTags: !0,
    editTags: { clicks: 2, keepInvalid: !0 },
    transformTag: () => {},
    trim: !0,
    a11y: { focusableTags: !1 },
    mixMode: { insertAfterTag: " " },
    autoComplete: { enabled: !0, rightKey: !1 },
    classNames: {
      namespace: "tagify",
      mixMode: "tagify--mix",
      selectMode: "tagify--select",
      input: "tagify__input",
      focus: "tagify--focus",
      tagNoAnimation: "tagify--noAnim",
      tagInvalid: "tagify--invalid",
      tagNotAllowed: "tagify--notAllowed",
      scopeLoading: "tagify--loading",
      hasMaxTags: "tagify--hasMaxTags",
      hasNoTags: "tagify--noTags",
      empty: "tagify--empty",
      inputInvalid: "tagify__input--invalid",
      dropdown: "tagify__dropdown",
      dropdownWrapper: "tagify__dropdown__wrapper",
      dropdownItem: "tagify__dropdown__item",
      dropdownItemActive: "tagify__dropdown__item--active",
      dropdownInital: "tagify__dropdown--initial",
      tag: "tagify__tag",
      tagText: "tagify__tag-text",
      tagX: "tagify__tag__removeBtn",
      tagLoading: "tagify__tag--loading",
      tagEditing: "tagify__tag--editable",
      tagFlash: "tagify__tag--flash",
      tagHide: "tagify__tag--hide",
    },
    dropdown: {
      classname: "",
      enabled: 2,
      maxItems: 10,
      searchKeys: ["value", "searchBy"],
      fuzzySearch: !0,
      caseSensitive: !1,
      accentedSearch: !0,
      highlightFirst: !1,
      closeOnSelect: !0,
      clearOnSelect: !0,
      position: "all",
      appendTarget: null,
    },
    hooks: {
      beforeRemoveTag: () => Promise.resolve(),
      beforePaste: () => Promise.resolve(),
      suggestionClick: () => Promise.resolve(),
    },
  };
  function u() {
    this.dropdown = {};
    for (let t in this._dropdown)
      this.dropdown[t] =
        "function" == typeof this._dropdown[t]
          ? this._dropdown[t].bind(this)
          : this._dropdown[t];
    this.dropdown.refs();
  }
  var m = {
    refs() {
      (this.DOM.dropdown = this.parseTemplate("dropdown", [this.settings])),
        (this.DOM.dropdown.content = this.DOM.dropdown.querySelector(
          this.settings.classNames.dropdownWrapperSelector
        ));
    },
    show(t) {
      var e,
        i,
        a,
        n = this.settings,
        o = "mix" == n.mode && !n.enforceWhitelist,
        r = !n.whitelist || !n.whitelist.length,
        d = "manual" == n.dropdown.position;
      if (
        ((t = void 0 === t ? this.state.inputText : t),
        (!r || o || n.templates.dropdownItemNoMatch) &&
          !1 !== n.dropdown.enable &&
          !this.state.isLoading)
      ) {
        if (
          (clearTimeout(this.dropdownHide__bindEventsTimeout),
          (this.suggestedListItems = this.dropdown.filterListItems(t)),
          t &&
            !this.suggestedListItems.length &&
            (this.trigger("dropdown:noMatch", t),
            n.templates.dropdownItemNoMatch &&
              (a = n.templates.dropdownItemNoMatch.call(this, { value: t }))),
          !a)
        ) {
          if (this.suggestedListItems.length)
            t &&
              o &&
              !this.state.editing.scope &&
              !s(this.suggestedListItems[0].value, t) &&
              this.suggestedListItems.unshift({ value: t });
          else {
            if (!t || !o || this.state.editing.scope)
              return (
                this.input.autocomplete.suggest.call(this),
                void this.dropdown.hide()
              );
            this.suggestedListItems = [{ value: t }];
          }
          (i = "" + (l((e = this.suggestedListItems[0])) ? e.value : e)),
            n.autoComplete &&
              i &&
              0 == i.indexOf(t) &&
              this.input.autocomplete.suggest.call(this, e);
        }
        this.dropdown.fill(a),
          n.dropdown.highlightFirst &&
            this.dropdown.highlightOption(
              this.DOM.dropdown.content.children[0]
            ),
          this.state.dropdown.visible ||
            setTimeout(this.dropdown.events.binding.bind(this)),
          (this.state.dropdown.visible = t || !0),
          (this.state.dropdown.query = t),
          this.setStateSelection(),
          d ||
            setTimeout(() => {
              this.dropdown.position(), this.dropdown.render();
            }),
          setTimeout(() => {
            this.trigger("dropdown:show", this.DOM.dropdown);
          });
      }
    },
    hide(t) {
      var e = this.DOM,
        i = e.scope,
        s = e.dropdown,
        a = "manual" == this.settings.dropdown.position && !t;
      if (s && document.body.contains(s) && !a)
        return (
          window.removeEventListener("resize", this.dropdown.position),
          this.dropdown.events.binding.call(this, !1),
          i.setAttribute("aria-expanded", !1),
          s.parentNode.removeChild(s),
          setTimeout(() => {
            this.state.dropdown.visible = !1;
          }, 100),
          (this.state.dropdown.query =
            this.state.ddItemData =
            this.state.ddItemElm =
            this.state.selection =
              null),
          this.state.tag &&
            this.state.tag.value.length &&
            (this.state.flaggedTags[this.state.tag.baseOffset] =
              this.state.tag),
          this.trigger("dropdown:hide", s),
          this
        );
    },
    toggle(t) {
      this.dropdown[this.state.dropdown.visible && !t ? "hide" : "show"]();
    },
    render() {
      var t,
        e,
        i,
        s =
          ((t = this.DOM.dropdown),
          ((i = t.cloneNode(!0)).style.cssText =
            "position:fixed; top:-9999px; opacity:0"),
          document.body.appendChild(i),
          (e = i.clientHeight),
          i.parentNode.removeChild(i),
          e),
        a = this.settings;
      return "number" == typeof a.dropdown.enabled && a.dropdown.enabled >= 0
        ? (this.DOM.scope.setAttribute("aria-expanded", !0),
          document.body.contains(this.DOM.dropdown) ||
            (this.DOM.dropdown.classList.add(a.classNames.dropdownInital),
            this.dropdown.position(s),
            a.dropdown.appendTarget.appendChild(this.DOM.dropdown),
            setTimeout(() =>
              this.DOM.dropdown.classList.remove(a.classNames.dropdownInital)
            )),
          this)
        : this;
    },
    fill(t) {
      var e;
      (t =
        "string" == typeof t
          ? t
          : this.dropdown.createListHTML(t || this.suggestedListItems)),
        (this.DOM.dropdown.content.innerHTML = (e = t)
          ? e
              .replace(/\>[\r\n ]+\</g, "><")
              .replace(/(<.*?>)|\s+/g, (t, e) => e || " ")
          : "");
    },
    refilter(t) {
      (t = t || this.state.dropdown.query || ""),
        (this.suggestedListItems = this.dropdown.filterListItems(t)),
        this.dropdown.fill(),
        this.suggestedListItems.length || this.dropdown.hide(),
        this.trigger("dropdown:updated", this.DOM.dropdown);
    },
    position(t) {
      var e = this.settings.dropdown;
      if ("manual" != e.position) {
        var i,
          s,
          a,
          n,
          o,
          r,
          l = this.DOM.dropdown,
          d = e.placeAbove,
          h = document.documentElement.clientHeight,
          g =
            Math.max(
              document.documentElement.clientWidth || 0,
              window.innerWidth || 0
            ) > 480
              ? e.position
              : "all",
          c = this.DOM["input" == g ? "input" : "scope"];
        (t = t || l.clientHeight),
          this.state.dropdown.visible &&
            ("text" == g
              ? ((a = (i = this.getCaretGlobalPosition()).bottom),
                (s = i.top),
                (n = i.left),
                (o = "auto"))
              : ((r = (function (t) {
                  for (var e = 0, i = 0; t; )
                    (e += t.offsetLeft || 0),
                      (i += t.offsetTop || 0),
                      (t = t.parentNode);
                  return { left: e, top: i };
                })(this.settings.dropdown.appendTarget)),
                (s = (i = c.getBoundingClientRect()).top - r.top),
                (a = i.bottom - 1 - r.top),
                (n = i.left - r.left),
                (o = i.width + "px")),
            (s = Math.floor(s)),
            (a = Math.ceil(a)),
            (d = void 0 === d ? h - i.bottom < t : d),
            (l.style.cssText =
              "left:" +
              (n + window.pageXOffset) +
              "px; width:" +
              o +
              ";" +
              (d
                ? "top: " + (s + window.pageYOffset) + "px"
                : "top: " + (a + window.pageYOffset) + "px")),
            l.setAttribute("placement", d ? "top" : "bottom"),
            l.setAttribute("position", g));
      }
    },
    events: {
      binding(t = !0) {
        var e = this.dropdown.events.callbacks,
          i = (this.listeners.dropdown = this.listeners.dropdown || {
            position: this.dropdown.position.bind(this),
            onKeyDown: e.onKeyDown.bind(this),
            onMouseOver: e.onMouseOver.bind(this),
            onMouseLeave: e.onMouseLeave.bind(this),
            onClick: e.onClick.bind(this),
            onScroll: e.onScroll.bind(this),
          }),
          s = t ? "addEventListener" : "removeEventListener";
        "manual" != this.settings.dropdown.position &&
          (window[s]("resize", i.position), window[s]("keydown", i.onKeyDown)),
          this.DOM.dropdown[s]("mouseover", i.onMouseOver),
          this.DOM.dropdown[s]("mouseleave", i.onMouseLeave),
          this.DOM.dropdown[s]("mousedown", i.onClick),
          this.DOM.dropdown.content[s]("scroll", i.onScroll);
      },
      callbacks: {
        onKeyDown(t) {
          var e = this.DOM.dropdown.querySelector(
              this.settings.classNames.dropdownItemActiveSelector
            ),
            i = this.dropdown.getSuggestionDataByNode(e);
          switch (t.key) {
            case "ArrowDown":
            case "ArrowUp":
            case "Down":
            case "Up":
              var s;
              t.preventDefault(),
                e &&
                  (e =
                    e[
                      ("ArrowUp" == t.key || "Up" == t.key
                        ? "previous"
                        : "next") + "ElementSibling"
                    ]),
                e ||
                  ((s = this.DOM.dropdown.content.children),
                  (e =
                    s["ArrowUp" == t.key || "Up" == t.key ? s.length - 1 : 0])),
                (i = this.dropdown.getSuggestionDataByNode(e)),
                this.dropdown.highlightOption(e, !0);
              break;
            case "Escape":
            case "Esc":
              this.dropdown.hide();
              break;
            case "ArrowRight":
              if (this.state.actions.ArrowLeft) return;
            case "Tab":
              if (
                "mix" != this.settings.mode &&
                e &&
                !this.settings.autoComplete.rightKey &&
                !this.state.editing
              ) {
                t.preventDefault();
                var a = this.dropdown.getMappedValue(i);
                return this.input.autocomplete.set.call(this, a), !1;
              }
              return !0;
            case "Enter":
              t.preventDefault(),
                this.settings.hooks
                  .suggestionClick(t, {
                    tagify: this,
                    tagData: i,
                    suggestionElm: e,
                  })
                  .then(() => {
                    if (e) return this.dropdown.selectOption(e);
                    this.dropdown.hide(),
                      "mix" != this.settings.mode &&
                        this.addTags(this.state.inputText.trim(), !0);
                  })
                  .catch((t) => t);
              break;
            case "Backspace": {
              if ("mix" == this.settings.mode || this.state.editing.scope)
                return;
              const t = this.input.raw.call(this);
              ("" != t && 8203 != t.charCodeAt(0)) ||
                (!0 === this.settings.backspace
                  ? this.removeTags()
                  : "edit" == this.settings.backspace &&
                    setTimeout(this.editTag.bind(this), 0));
            }
          }
        },
        onMouseOver(t) {
          var e = t.target.closest(
            this.settings.classNames.dropdownItemSelector
          );
          e && this.dropdown.highlightOption(e);
        },
        onMouseLeave(t) {
          this.dropdown.highlightOption();
        },
        onClick(t) {
          if (
            0 == t.button &&
            t.target != this.DOM.dropdown &&
            t.target != this.DOM.dropdown.content
          ) {
            var e = t.target.closest(
                this.settings.classNames.dropdownItemSelector
              ),
              i = this.dropdown.getSuggestionDataByNode(e);
            (this.state.actions.selectOption = !0),
              setTimeout(() => (this.state.actions.selectOption = !1), 50),
              this.settings.hooks
                .suggestionClick(t, {
                  tagify: this,
                  tagData: i,
                  suggestionElm: e,
                })
                .then(() => {
                  e ? this.dropdown.selectOption(e) : this.dropdown.hide();
                })
                .catch((t) => console.warn(t));
          }
        },
        onScroll(t) {
          var e = t.target,
            i =
              (e.scrollTop / (e.scrollHeight - e.parentNode.clientHeight)) *
              100;
          this.trigger("dropdown:scroll", { percentage: Math.round(i) });
        },
      },
    },
    getSuggestionDataByNode(t) {
      var e = t ? +t.getAttribute("tagifySuggestionIdx") : -1;
      return this.suggestedListItems[e] || null;
    },
    highlightOption(t, e) {
      var i,
        s = this.settings.classNames.dropdownItemActive;
      if (
        (this.state.ddItemElm &&
          (this.state.ddItemElm.classList.remove(s),
          this.state.ddItemElm.removeAttribute("aria-selected")),
        !t)
      )
        return (
          (this.state.ddItemData = null),
          (this.state.ddItemElm = null),
          void this.input.autocomplete.suggest.call(this)
        );
      (i = this.suggestedListItems[this.getNodeIndex(t)]),
        (this.state.ddItemData = i),
        (this.state.ddItemElm = t),
        t.classList.add(s),
        t.setAttribute("aria-selected", !0),
        e &&
          (t.parentNode.scrollTop =
            t.clientHeight + t.offsetTop - t.parentNode.clientHeight),
        this.settings.autoComplete &&
          (this.input.autocomplete.suggest.call(this, i),
          this.dropdown.position());
    },
    selectOption(t) {
      var e = this.settings.dropdown,
        i = e.clearOnSelect,
        s = e.closeOnSelect;
      if (!t)
        return (
          this.addTags(this.state.inputText, !0),
          void (s && this.dropdown.hide())
        );
      var a = t.getAttribute("tagifySuggestionIdx"),
        n = this.suggestedListItems[+a];
      this.trigger("dropdown:select", { data: n, elm: t }),
        a && n
          ? (this.state.editing
              ? this.onEditTagDone(
                  null,
                  d({ __isValid: !0 }, this.normalizeTags([n])[0])
                )
              : this["mix" == this.settings.mode ? "addMixTags" : "addTags"](
                  [n],
                  i
                ),
            this.DOM.input.parentNode &&
              (setTimeout(() => {
                this.DOM.input.focus(), this.toggleFocusClass(!0);
              }),
              s
                ? setTimeout(this.dropdown.hide.bind(this))
                : this.dropdown.refilter()))
          : this.dropdown.hide();
    },
    selectAll() {
      return (
        (this.suggestedListItems.length = 0),
        this.dropdown.hide(),
        this.addTags(this.dropdown.filterListItems(""), !0),
        this
      );
    },
    filterListItems(t, e) {
      var i,
        s,
        a,
        n,
        o,
        r = this.settings,
        d = r.dropdown,
        g =
          ((e = e || {}),
          (t =
            "select" == r.mode &&
            this.value.length &&
            this.value[0][r.tagTextProp] == t
              ? ""
              : t),
          []),
        c = [],
        p = r.whitelist,
        u = d.maxItems || 1 / 0,
        m = d.searchKeys,
        v = 0;
      if (!t || !m.length)
        return (
          r.duplicates
            ? p
            : p.filter((t) => !this.isTagDuplicate(l(t) ? t.value : t))
        ).slice(0, u);
      function f(t, e) {
        return e
          .toLowerCase()
          .split(" ")
          .every((e) => t.includes(e.toLowerCase()));
      }
      for (
        o = d.caseSensitive ? "" + t : ("" + t).toLowerCase();
        v < p.length;
        v++
      ) {
        let t, u;
        i = p[v] instanceof Object ? p[v] : { value: p[v] };
        let T = !Object.keys(i).some((t) => m.includes(t)) ? ["value"] : m;
        d.fuzzySearch && !e.exact
          ? ((a = T.reduce((t, e) => t + " " + (i[e] || ""), "")
              .toLowerCase()
              .trim()),
            d.accentedSearch && ((a = h(a)), (o = h(o))),
            (t = 0 == a.indexOf(o)),
            (u = a === o),
            (s = f(a, o)))
          : ((t = !0),
            (s = T.some((t) => {
              var s = "" + (i[t] || "");
              return (
                d.accentedSearch && ((s = h(s)), (o = h(o))),
                d.caseSensitive || (s = s.toLowerCase()),
                (u = s === o),
                e.exact ? s === o : 0 == s.indexOf(o)
              );
            }))),
          (n = !r.duplicates && this.isTagDuplicate(l(i) ? i.value : i)),
          s &&
            !n &&
            (u && t
              ? c.push(i)
              : "startsWith" == d.sortby && t
              ? g.unshift(i)
              : g.push(i));
      }
      return "function" == typeof d.sortby
        ? d.sortby(c.concat(g), o)
        : c.concat(g).slice(0, u);
    },
    getMappedValue(t) {
      var e = this.settings.dropdown.mapValueTo;
      return e ? ("function" == typeof e ? e(t) : t[e] || t.value) : t.value;
    },
    createListHTML(t) {
      return d([], t)
        .map((t, e) => {
          ("string" != typeof t && "number" != typeof t) || (t = { value: t });
          var i = this.dropdown.getMappedValue(t);
          t.value = i && "string" == typeof i ? r(i) : i;
          var s = this.settings.templates.dropdownItem.apply(this, [t, this]);
          return (s = s
            .replace(/\s*tagifySuggestionIdx=(["'])(.*?)\1/gim, "")
            .replace(">", ` tagifySuggestionIdx="${e}">`));
        })
        .join("");
    },
  };
  const v = "@yaireo/tagify/";
  var f,
    T = {
      empty: "empty",
      exceed: "number of tags exceeded",
      pattern: "pattern mismatch",
      duplicate: "already exists",
      notAllowed: "not allowed",
    },
    w = {
      wrapper: (t, e) =>
        `<tags class="${e.classNames.namespace} ${
          e.mode ? `${e.classNames[e.mode + "Mode"]}` : ""
        } ${t.className}"\n                    ${
          e.readonly ? "readonly" : ""
        }\n                    ${
          e.disabled ? "disabled" : ""
        }\n                    ${
          e.required ? "required" : ""
        }\n                    tabIndex="-1">\n            <span ${
          !e.readonly && e.userInput ? "contenteditable" : ""
        } tabIndex="0" data-placeholder="${
          e.placeholder || "&#8203;"
        }" aria-placeholder="${e.placeholder || ""}"\n                class="${
          e.classNames.input
        }"\n                role="textbox"\n                aria-autocomplete="both"\n                aria-multiline="${
          "mix" == e.mode
        }"></span>\n                &#8203;\n        </tags>`,
      tag(t, e) {
        var i = this.settings;
        return `<tag title="${
          t.title || t.value
        }"\n                    contenteditable='false'\n                    spellcheck='false'\n                    tabIndex="${
          i.a11y.focusableTags ? 0 : -1
        }"\n                    class="${i.classNames.tag} ${
          t.class || ""
        }"\n                    ${this.getAttributes(
          t
        )}>\n            <x title='' class="${
          i.classNames.tagX
        }" role='button' aria-label='remove tag'></x>\n            <div>\n                <span class="${
          i.classNames.tagText
        }">${
          t[i.tagTextProp] || t.value
        }</span>\n            </div>\n        </tag>`;
      },
      dropdown(t) {
        var e = t.dropdown,
          i = "manual" == e.position,
          s = `${t.classNames.dropdown}`;
        return `<div class="${i ? "" : s} ${
          e.classname
        }" role="listbox" aria-labelledby="dropdown">\n                    <div class="${
          t.classNames.dropdownWrapper
        }"></div>\n                </div>`;
      },
      dropdownItem(t, e) {
        return `<div ${this.getAttributes(t)}\n                    class='${
          this.settings.classNames.dropdownItem
        } ${
          t.class ? t.class : ""
        }'\n                    tabindex="0"\n                    role="option">${
          t.value
        }</div>`;
      },
      dropdownItemNoMatch: null,
    };
  var b = {
    customBinding() {
      this.customEventsList.forEach((t) => {
        this.on(t, this.settings.callbacks[t]);
      });
    },
    binding(t = !0) {
      var e,
        i = this.events.callbacks,
        s = t ? "addEventListener" : "removeEventListener";
      if (!this.state.mainEvents || !t) {
        for (var a in ((this.state.mainEvents = t),
        t &&
          !this.listeners.main &&
          (this.events.bindGlobal.call(this),
          this.settings.isJQueryPlugin &&
            jQuery(this.DOM.originalInput).on(
              "tagify.removeAllTags",
              this.removeAllTags.bind(this)
            )),
        (e = this.listeners.main =
          this.listeners.main || {
            focus: ["input", i.onFocusBlur.bind(this)],
            keydown: ["input", i.onKeydown.bind(this)],
            click: ["scope", i.onClickScope.bind(this)],
            dblclick: ["scope", i.onDoubleClickScope.bind(this)],
            paste: ["input", i.onPaste.bind(this)],
            drop: ["input", i.onDrop.bind(this)],
          })))
          this.DOM[e[a][0]][s](a, e[a][1]);
        clearInterval(this.listeners.main.originalInputValueObserverInterval),
          (this.listeners.main.originalInputValueObserverInterval = setInterval(
            i.observeOriginalInputValue.bind(this),
            500
          ));
        var n =
          this.listeners.main.inputMutationObserver ||
          new MutationObserver(i.onInputDOMChange.bind(this));
        n && n.disconnect(),
          "mix" == this.settings.mode &&
            n.observe(this.DOM.input, { childList: !0 });
      }
    },
    bindGlobal(t) {
      var e,
        i = this.events.callbacks,
        s = t ? "removeEventListener" : "addEventListener";
      if (t || !this.listeners.global)
        for (e of ((this.listeners.global = (this.listeners &&
          this.listeners.global) || [
          {
            type: this.isIE ? "keydown" : "input",
            target: this.DOM.input,
            cb: i[this.isIE ? "onInputIE" : "onInput"].bind(this),
          },
          { type: "keydown", target: window, cb: i.onWindowKeyDown.bind(this) },
          {
            type: "blur",
            target: this.DOM.input,
            cb: i.onFocusBlur.bind(this),
          },
        ]),
        this.listeners.global))
          e.target[s](e.type, e.cb);
    },
    unbindGlobal() {
      this.events.bindGlobal.call(this, !0);
    },
    callbacks: {
      onFocusBlur(t) {
        var e = t.target ? this.trim(t.target.textContent) : "",
          i = this.settings,
          s = t.type,
          a = i.dropdown.enabled >= 0,
          n = { relatedTarget: t.relatedTarget },
          o =
            this.state.actions.selectOption && (a || !i.dropdown.closeOnSelect),
          r = this.state.actions.addNew && a,
          l =
            t.relatedTarget &&
            c.call(this, t.relatedTarget) &&
            this.DOM.scope.contains(t.relatedTarget);
        if ("blur" == s) {
          if (t.relatedTarget === this.DOM.scope)
            return this.dropdown.hide(), void this.DOM.input.focus();
          this.postUpdate(), this.triggerChangeEvent();
        }
        if (!o && !r)
          if (
            ((this.state.hasFocus = "focus" == s && +new Date()),
            this.toggleFocusClass(this.state.hasFocus),
            "mix" != i.mode)
          ) {
            if ("focus" == s)
              return (
                this.trigger("focus", n),
                void (
                  (0 !== i.dropdown.enabled && i.userInput) ||
                  this.dropdown.show(this.value.length ? "" : void 0)
                )
              );
            "blur" == s &&
              (this.trigger("blur", n),
              this.loading(!1),
              "select" == this.settings.mode && l && (e = ""),
              ("select" == this.settings.mode && e
                ? !this.value.length || this.value[0].value != e
                : e && !this.state.actions.selectOption && i.addTagOnBlur) &&
                this.addTags(e, !0),
              "select" != this.settings.mode || e || this.removeTags()),
              this.DOM.input.removeAttribute("style"),
              this.dropdown.hide();
          } else
            "focus" == s
              ? this.trigger("focus", n)
              : "blur" == t.type &&
                (this.trigger("blur", n),
                this.loading(!1),
                this.dropdown.hide(),
                (this.state.dropdown.visible = void 0),
                this.setStateSelection());
      },
      onWindowKeyDown(t) {
        var e,
          i = document.activeElement;
        if (c.call(this, i) && this.DOM.scope.contains(document.activeElement))
          switch (((e = i.nextElementSibling), t.key)) {
            case "Backspace":
              this.settings.readonly ||
                (this.removeTags(i), (e || this.DOM.input).focus());
              break;
            case "Enter":
              setTimeout(this.editTag.bind(this), 0, i);
          }
      },
      onKeydown(t) {
        var e = this.settings;
        "select" == e.mode &&
          e.enforceWhitelist &&
          this.value.length &&
          "Tab" != t.key &&
          t.preventDefault();
        var i = this.trim(t.target.textContent);
        if (
          (this.trigger("keydown", { originalEvent: this.cloneEvent(t) }),
          "mix" == e.mode)
        ) {
          switch (t.key) {
            case "Left":
            case "ArrowLeft":
              this.state.actions.ArrowLeft = !0;
              break;
            case "Delete":
            case "Backspace":
              if (this.state.editing) return;
              var s,
                a,
                r,
                l = document.getSelection(),
                d =
                  "Delete" == t.key &&
                  l.anchorOffset == (l.anchorNode.length || 0),
                h = l.anchorNode.previousSibling,
                p =
                  1 == l.anchorNode.nodeType ||
                  (!l.anchorOffset &&
                    h &&
                    1 == h.nodeType &&
                    l.anchorNode.previousSibling),
                u = n(this.DOM.input.innerHTML),
                m = this.getTagElms();
              if ("edit" == e.backspace && p)
                return (
                  (s =
                    1 == l.anchorNode.nodeType
                      ? null
                      : l.anchorNode.previousElementSibling),
                  setTimeout(this.editTag.bind(this), 0, s),
                  void t.preventDefault()
                );
              if (g() && p)
                return (
                  (r = o(p)),
                  p.hasAttribute("readonly") || p.remove(),
                  this.DOM.input.focus(),
                  void setTimeout(() => {
                    this.placeCaretAfterNode(r), this.DOM.input.click();
                  })
                );
              if ("BR" == l.anchorNode.nodeName) return;
              if (
                ((d || p) && 1 == l.anchorNode.nodeType
                  ? (a =
                      0 == l.anchorOffset
                        ? d
                          ? m[0]
                          : null
                        : m[l.anchorOffset - 1])
                  : d
                  ? (a = l.anchorNode.nextElementSibling)
                  : p && (a = p),
                3 == l.anchorNode.nodeType &&
                  !l.anchorNode.nodeValue &&
                  l.anchorNode.previousElementSibling &&
                  t.preventDefault(),
                (p || d) && !e.backspace)
              )
                return void t.preventDefault();
              if (
                "Range" != l.type &&
                !l.anchorOffset &&
                l.anchorNode == this.DOM.input &&
                "Delete" != t.key
              )
                return void t.preventDefault();
              if ("Range" != l.type && a && a.hasAttribute("readonly"))
                return void this.placeCaretAfterNode(o(a));
              clearTimeout(f),
                (f = setTimeout(() => {
                  var t = document.getSelection(),
                    e = n(this.DOM.input.innerHTML),
                    i = !d && t.anchorNode.previousSibling;
                  if (e.length >= u.length && i)
                    if (c.call(this, i) && !i.hasAttribute("readonly")) {
                      if (
                        (this.removeTags(i),
                        this.fixFirefoxLastTagNoCaret(),
                        2 == this.DOM.input.children.length &&
                          "BR" == this.DOM.input.children[1].tagName)
                      )
                        return (
                          (this.DOM.input.innerHTML = ""),
                          (this.value.length = 0),
                          !0
                        );
                    } else i.remove();
                  this.value = [].map
                    .call(m, (t, e) => {
                      var i = this.tagData(t);
                      if (t.parentNode || i.readonly) return i;
                      this.trigger("remove", { tag: t, index: e, data: i });
                    })
                    .filter((t) => t);
                }, 20));
          }
          return !0;
        }
        switch (t.key) {
          case "Backspace":
            "select" == e.mode && e.enforceWhitelist && this.value.length
              ? this.removeTags()
              : (this.state.dropdown.visible &&
                  "manual" != e.dropdown.position) ||
                ("" != t.target.textContent && 8203 != i.charCodeAt(0)) ||
                (!0 === e.backspace
                  ? this.removeTags()
                  : "edit" == e.backspace &&
                    setTimeout(this.editTag.bind(this), 0));
            break;
          case "Esc":
          case "Escape":
            if (this.state.dropdown.visible) return;
            t.target.blur();
            break;
          case "Down":
          case "ArrowDown":
            this.state.dropdown.visible || this.dropdown.show();
            break;
          case "ArrowRight": {
            let t = this.state.inputSuggestion || this.state.ddItemData;
            if (t && e.autoComplete.rightKey) return void this.addTags([t], !0);
            break;
          }
          case "Tab": {
            let s = "select" == e.mode;
            if (!i || s) return !0;
            t.preventDefault();
          }
          case "Enter":
            if (this.state.dropdown.visible || 229 == t.keyCode) return;
            t.preventDefault(),
              setTimeout(() => {
                this.state.actions.selectOption || this.addTags(i, !0);
              });
        }
      },
      onInput(t) {
        if ((this.postUpdate(), "mix" == this.settings.mode))
          return this.events.callbacks.onMixTagsInput.call(this, t);
        var e = this.input.normalize.call(this),
          i = e.length >= this.settings.dropdown.enabled,
          s = { value: e, inputElm: this.DOM.input };
        (s.isValid = this.validateTag({ value: e })),
          this.state.inputText != e &&
            (this.input.set.call(this, e, !1),
            -1 != e.search(this.settings.delimiters)
              ? this.addTags(e) && this.input.set.call(this)
              : this.settings.dropdown.enabled >= 0 &&
                this.dropdown[i ? "show" : "hide"](e),
            this.trigger("input", s));
      },
      onMixTagsInput(t) {
        var e,
          i,
          s,
          a,
          n,
          o,
          r,
          l,
          h = this.settings,
          c = this.value.length,
          p = this.getTagElms(),
          u = document.createDocumentFragment(),
          m = window.getSelection().getRangeAt(0),
          v = [].map.call(p, (t) => this.tagData(t).value);
        if (
          ("deleteContentBackward" == t.inputType &&
            g() &&
            this.events.callbacks.onKeydown.call(this, {
              target: t.target,
              key: "Backspace",
            }),
          this.value.slice().forEach((t) => {
            t.readonly &&
              !v.includes(t.value) &&
              u.appendChild(this.createTagElem(t));
          }),
          u.childNodes.length &&
            (m.insertNode(u), this.setRangeAtStartEnd(!1, u.lastChild)),
          p.length != c)
        )
          return (
            (this.value = [].map.call(this.getTagElms(), (t) =>
              this.tagData(t)
            )),
            void this.update({ withoutChangeEvent: !0 })
          );
        if (this.hasMaxTags()) return !0;
        if (
          window.getSelection &&
          (o = window.getSelection()).rangeCount > 0 &&
          3 == o.anchorNode.nodeType
        ) {
          if (
            ((m = o.getRangeAt(0).cloneRange()).collapse(!0),
            m.setStart(o.focusNode, 0),
            (s =
              (e = m.toString().slice(0, m.endOffset)).split(h.pattern).length -
              1),
            (i = e.match(h.pattern)) &&
              (a = e.slice(e.lastIndexOf(i[i.length - 1]))),
            a)
          ) {
            if (
              ((this.state.actions.ArrowLeft = !1),
              (this.state.tag = {
                prefix: a.match(h.pattern)[0],
                value: a.replace(h.pattern, ""),
              }),
              (this.state.tag.baseOffset =
                o.baseOffset - this.state.tag.value.length),
              (l = this.state.tag.value.match(h.delimiters)))
            )
              return (
                (this.state.tag.value = this.state.tag.value.replace(
                  h.delimiters,
                  ""
                )),
                (this.state.tag.delimiters = l[0]),
                this.addTags(this.state.tag.value, h.dropdown.clearOnSelect),
                void this.dropdown.hide()
              );
            n = this.state.tag.value.length >= h.dropdown.enabled;
            try {
              (r =
                (r = this.state.flaggedTags[this.state.tag.baseOffset])
                  .prefix == this.state.tag.prefix &&
                r.value[0] == this.state.tag.value[0]),
                this.state.flaggedTags[this.state.tag.baseOffset] &&
                  !this.state.tag.value &&
                  delete this.state.flaggedTags[this.state.tag.baseOffset];
            } catch (t) {}
            (r || s < this.state.mixMode.matchedPatternCount) && (n = !1);
          } else this.state.flaggedTags = {};
          this.state.mixMode.matchedPatternCount = s;
        }
        setTimeout(() => {
          this.update({ withoutChangeEvent: !0 }),
            this.trigger(
              "input",
              d({}, this.state.tag, { textContent: this.DOM.input.textContent })
            ),
            this.state.tag &&
              this.dropdown[n ? "show" : "hide"](this.state.tag.value);
        }, 10);
      },
      onInputIE(t) {
        var e = this;
        setTimeout(function () {
          e.events.callbacks.onInput.call(e, t);
        });
      },
      observeOriginalInputValue() {
        this.DOM.originalInput.value != this.DOM.originalInput.tagifyValue &&
          this.loadOriginalValues();
      },
      onClickScope(t) {
        var e = this.settings,
          i = t.target.closest("." + e.classNames.tag),
          s = +new Date() - this.state.hasFocus;
        if (t.target != this.DOM.scope) {
          if (!t.target.classList.contains(e.classNames.tagX))
            return i
              ? (this.trigger("click", {
                  tag: i,
                  index: this.getNodeIndex(i),
                  data: this.tagData(i),
                  originalEvent: this.cloneEvent(t),
                }),
                void (
                  (1 !== e.editTags && 1 !== e.editTags.clicks) ||
                  this.events.callbacks.onDoubleClickScope.call(this, t)
                ))
              : void (t.target == this.DOM.input &&
                ("mix" == e.mode && this.fixFirefoxLastTagNoCaret(), s > 500)
                  ? this.state.dropdown.visible
                    ? this.dropdown.hide()
                    : 0 === e.dropdown.enabled &&
                      "mix" != e.mode &&
                      this.dropdown.show(this.value.length ? "" : void 0)
                  : "select" == e.mode &&
                    !this.state.dropdown.visible &&
                    this.dropdown.show());
          this.removeTags(t.target.parentNode);
        } else this.state.hasFocus || this.DOM.input.focus();
      },
      onPaste(t) {
        t.preventDefault();
        var e,
          i,
          s = this.settings;
        if (("select" == s.mode && s.enforceWhitelist) || !s.userInput)
          return !1;
        s.readonly ||
          ((e = t.clipboardData || window.clipboardData),
          (i = e.getData("Text")),
          s.hooks
            .beforePaste(t, { tagify: this, pastedText: i, clipboardData: e })
            .then((e) => {
              void 0 === e && (e = i),
                e &&
                  (this.injectAtCaret(e, window.getSelection().getRangeAt(0)),
                  "mix" == this.settings.mode
                    ? this.events.callbacks.onMixTagsInput.call(this, t)
                    : this.settings.pasteAsTags
                    ? this.addTags(this.state.inputText + e, !0)
                    : (this.state.inputText = e));
            })
            .catch((t) => t));
      },
      onDrop(t) {
        t.preventDefault();
      },
      onEditTagInput(t, e) {
        var i = t.closest("." + this.settings.classNames.tag),
          s = this.getNodeIndex(i),
          a = this.tagData(i),
          n = this.input.normalize.call(this, t),
          o = i.innerHTML != i.__tagifyTagData.__originalHTML,
          r = this.validateTag({ [this.settings.tagTextProp]: n });
        o || !0 !== t.originalIsValid || (r = !0),
          i.classList.toggle(this.settings.classNames.tagInvalid, !0 !== r),
          (a.__isValid = r),
          (i.title = !0 === r ? a.title || a.value : r),
          n.length >= this.settings.dropdown.enabled &&
            (this.state.editing && (this.state.editing.value = n),
            this.dropdown.show(n)),
          this.trigger("edit:input", {
            tag: i,
            index: s,
            data: d({}, this.value[s], { newValue: n }),
            originalEvent: this.cloneEvent(e),
          });
      },
      onEditTagFocus(t) {
        this.state.editing = {
          scope: t,
          input: t.querySelector("[contenteditable]"),
        };
      },
      onEditTagBlur(t) {
        if (
          (this.state.hasFocus || this.toggleFocusClass(),
          this.DOM.scope.contains(t))
        ) {
          var e,
            i,
            s = this.settings,
            a = t.closest("." + s.classNames.tag),
            n = this.input.normalize.call(this, t),
            o = this.tagData(a).__originalData,
            r = a.innerHTML != a.__tagifyTagData.__originalHTML,
            l = this.validateTag({ [s.tagTextProp]: n });
          if (n)
            if (r) {
              if (
                ((e = this.hasMaxTags()),
                (i =
                  this.getWhitelistItem(n) ||
                  d({}, o, { [s.tagTextProp]: n, value: n, __isValid: l })),
                s.transformTag.call(this, i, o),
                !0 !==
                  (l =
                    (!e || !0 === o.__isValid) &&
                    this.validateTag({ [s.tagTextProp]: i[s.tagTextProp] })))
              ) {
                if (
                  (this.trigger("invalid", { data: i, tag: a, message: l }),
                  s.editTags.keepInvalid)
                )
                  return;
                s.keepInvalidTags ? (i.__isValid = l) : (i = o);
              } else
                s.keepInvalidTags &&
                  (delete i.title, delete i["aria-invalid"], delete i.class);
              this.onEditTagDone(a, i);
            } else this.onEditTagDone(a, o);
          else this.onEditTagDone(a);
        }
      },
      onEditTagkeydown(t, e) {
        switch (
          (this.trigger("edit:keydown", { originalEvent: this.cloneEvent(t) }),
          t.key)
        ) {
          case "Esc":
          case "Escape":
            e.innerHTML = e.__tagifyTagData.__originalHTML;
          case "Enter":
          case "Tab":
            t.preventDefault(), t.target.blur();
        }
      },
      onDoubleClickScope(t) {
        var e,
          i,
          s = t.target.closest("." + this.settings.classNames.tag),
          a = this.settings;
        s &&
          a.userInput &&
          ((e = s.classList.contains(this.settings.classNames.tagEditing)),
          (i = s.hasAttribute("readonly")),
          "select" == a.mode ||
            a.readonly ||
            e ||
            i ||
            !this.settings.editTags ||
            this.editTag(s),
          this.toggleFocusClass(!0),
          this.trigger("dblclick", {
            tag: s,
            index: this.getNodeIndex(s),
            data: this.tagData(s),
          }));
      },
      onInputDOMChange(t) {
        t.forEach((t) => {
          t.addedNodes.forEach((t) => {
            if (t)
              if ("<div><br></div>" == t.outerHTML)
                t.replaceWith(document.createElement("br"));
              else if (
                1 == t.nodeType &&
                t.querySelector(this.settings.classNames.tagSelector)
              ) {
                let e = document.createTextNode("");
                3 == t.childNodes[0].nodeType &&
                  "BR" != t.previousSibling.nodeName &&
                  (e = document.createTextNode("\n")),
                  t.replaceWith(e, ...[...t.childNodes].slice(0, -1)),
                  this.placeCaretAfterNode(e.previousSibling);
              } else
                c.call(this, t) &&
                  t.previousSibling &&
                  "BR" == t.previousSibling.nodeName &&
                  (t.previousSibling.replaceWith("\n​"),
                  this.placeCaretAfterNode(t.previousSibling.previousSibling));
          }),
            t.removedNodes.forEach((t) => {
              t &&
                "BR" == t.nodeName &&
                c.call(this, e) &&
                (this.removeTags(e), this.fixFirefoxLastTagNoCaret());
            });
        });
        var e = this.DOM.input.lastChild;
        e && "" == e.nodeValue && e.remove(),
          (e && "BR" == e.nodeName) ||
            this.DOM.input.appendChild(document.createElement("br"));
      },
    },
  };
  function y(t, e) {
    if (!t) {
      console.warn("Tagify:", "input element not found", t);
      const e = new Proxy(this, { get: () => () => e });
      return e;
    }
    if (
      t.previousElementSibling &&
      t.previousElementSibling.classList.contains("tagify")
    )
      return (
        console.warn("Tagify: ", "input element is already Tagified", t), this
      );
    var i;
    d(
      this,
      (function (t) {
        var e = document.createTextNode("");
        function i(t, i, s) {
          s &&
            i
              .split(/\s+/g)
              .forEach((i) => e[t + "EventListener"].call(e, i, s));
        }
        return {
          off(t, e) {
            return i("remove", t, e), this;
          },
          on(t, e) {
            return e && "function" == typeof e && i("add", t, e), this;
          },
          trigger(i, s, a) {
            var n;
            if (((a = a || { cloneData: !0 }), i))
              if (t.settings.isJQueryPlugin)
                "remove" == i && (i = "removeTag"),
                  jQuery(t.DOM.originalInput).triggerHandler(i, [s]);
              else {
                try {
                  var o = "object" == typeof s ? s : { value: s };
                  if (
                    (((o = a.cloneData ? d({}, o) : o).tagify = this),
                    s instanceof Object)
                  )
                    for (var r in s)
                      s[r] instanceof HTMLElement && (o[r] = s[r]);
                  n = new CustomEvent(i, { detail: o });
                } catch (t) {
                  console.warn(t);
                }
                e.dispatchEvent(n);
              }
          },
        };
      })(this)
    ),
      (this.isFirefox = "undefined" != typeof InstallTrigger),
      (this.isIE = window.document.documentMode),
      (e = e || {}),
      (this.getPersistedData =
        ((i = e.id),
        (t) => {
          let e,
            s = "/" + t;
          if (1 == localStorage.getItem(v + i + "/v", 1))
            try {
              e = JSON.parse(localStorage[v + i + s]);
            } catch (t) {}
          return e;
        })),
      (this.setPersistedData = ((t) =>
        t
          ? (localStorage.setItem(v + t + "/v", 1),
            (e, i) => {
              let s = "/" + i,
                a = JSON.stringify(e);
              e &&
                i &&
                (localStorage.setItem(v + t + s, a),
                dispatchEvent(new Event("storage")));
            })
          : () => {})(e.id)),
      (this.clearPersistedData = ((t) => (e) => {
        const i = v + "/" + t + "/";
        if (e) localStorage.removeItem(i + e);
        else
          for (let t in localStorage)
            t.includes(i) && localStorage.removeItem(t);
      })(e.id)),
      this.applySettings(t, e),
      (this.state = {
        inputText: "",
        editing: !1,
        actions: {},
        mixMode: {},
        dropdown: {},
        flaggedTags: {},
      }),
      (this.value = []),
      (this.listeners = {}),
      (this.DOM = {}),
      this.build(t),
      u.call(this),
      this.getCSSVars(),
      this.loadOriginalValues(),
      this.events.customBinding.call(this),
      this.events.binding.call(this),
      t.autofocus && this.DOM.input.focus();
  }
  return (
    (y.prototype = {
      _dropdown: m,
      customEventsList: [
        "change",
        "add",
        "remove",
        "invalid",
        "input",
        "click",
        "keydown",
        "focus",
        "blur",
        "edit:input",
        "edit:beforeUpdate",
        "edit:updated",
        "edit:start",
        "edit:keydown",
        "dropdown:show",
        "dropdown:hide",
        "dropdown:select",
        "dropdown:updated",
        "dropdown:noMatch",
        "dropdown:scroll",
      ],
      dataProps: [
        "__isValid",
        "__removed",
        "__originalData",
        "__originalHTML",
        "__tagId",
      ],
      trim(t) {
        return this.settings.trim && t && "string" == typeof t ? t.trim() : t;
      },
      parseHTML: function (t) {
        return new DOMParser().parseFromString(t.trim(), "text/html").body
          .firstElementChild;
      },
      templates: w,
      parseTemplate(t, e) {
        return (
          (t = this.settings.templates[t] || t),
          this.parseHTML(t.apply(this, e))
        );
      },
      set whitelist(t) {
        const e = t && Array.isArray(t);
        (this.settings.whitelist = e ? t : []),
          this.setPersistedData(e ? t : [], "whitelist");
      },
      get whitelist() {
        return this.settings.whitelist;
      },
      applySettings(t, i) {
        p.templates = this.templates;
        var s = (this.settings = d({}, p, i));
        (s.disabled = t.hasAttribute("disabled")),
          (s.readonly = s.readonly || t.hasAttribute("readonly")),
          (s.placeholder = r(
            t.getAttribute("placeholder") || s.placeholder || ""
          )),
          (s.required = t.hasAttribute("required"));
        for (let t in s.classNames)
          Object.defineProperty(s.classNames, t + "Selector", {
            get() {
              return "." + this[t].split(" ")[0];
            },
          });
        if (
          (this.isIE && (s.autoComplete = !1),
          ["whitelist", "blacklist"].forEach((e) => {
            var i = t.getAttribute("data-" + e);
            i && (i = i.split(s.delimiters)) instanceof Array && (s[e] = i);
          }),
          "autoComplete" in i &&
            !l(i.autoComplete) &&
            ((s.autoComplete = p.autoComplete),
            (s.autoComplete.enabled = i.autoComplete)),
          "mix" == s.mode &&
            ((s.autoComplete.rightKey = !0),
            (s.delimiters = i.delimiters || null),
            s.tagTextProp &&
              !s.dropdown.searchKeys.includes(s.tagTextProp) &&
              s.dropdown.searchKeys.push(s.tagTextProp)),
          t.pattern)
        )
          try {
            s.pattern = new RegExp(t.pattern);
          } catch (t) {}
        if (this.settings.delimiters)
          try {
            s.delimiters = new RegExp(this.settings.delimiters, "g");
          } catch (t) {}
        s.disabled && (s.userInput = !1),
          (this.TEXTS = e(e({}, T), s.texts || {})),
          ("select" != s.mode && s.userInput) || (s.dropdown.enabled = 0),
          (s.dropdown.appendTarget =
            i.dropdown && i.dropdown.appendTarget
              ? i.dropdown.appendTarget
              : document.body);
        let a = this.getPersistedData("whitelist");
        Array.isArray(a) &&
          (this.whitelist = Array.isArray(s.whitelist)
            ? (function () {
                const t = [],
                  e = {};
                for (let i of arguments)
                  for (let s of i)
                    l(s)
                      ? e[s.value] || (t.push(s), (e[s.value] = 1))
                      : t.includes(s) || t.push(s);
                return t;
              })(s.whitelist, a)
            : a);
      },
      getAttributes(t) {
        var e,
          i = this.getCustomAttributes(t),
          s = "";
        for (e in i) s += " " + e + (void 0 !== t[e] ? `="${i[e]}"` : "");
        return s;
      },
      getCustomAttributes(t) {
        if (!l(t)) return "";
        var e,
          i = {};
        for (e in t)
          "__" != e.slice(0, 2) &&
            "class" != e &&
            t.hasOwnProperty(e) &&
            void 0 !== t[e] &&
            (i[e] = r(t[e]));
        return i;
      },
      setStateSelection() {
        var t = window.getSelection(),
          e = {
            anchorOffset: t.anchorOffset,
            anchorNode: t.anchorNode,
            range: t.getRangeAt && t.rangeCount && t.getRangeAt(0),
          };
        return (this.state.selection = e), e;
      },
      getCaretGlobalPosition() {
        const t = document.getSelection();
        if (t.rangeCount) {
          const e = t.getRangeAt(0),
            i = e.startContainer,
            s = e.startOffset;
          let a, n;
          if (s > 0)
            return (
              (n = document.createRange()),
              n.setStart(i, s - 1),
              n.setEnd(i, s),
              (a = n.getBoundingClientRect()),
              { left: a.right, top: a.top, bottom: a.bottom }
            );
          if (i.getBoundingClientRect) return i.getBoundingClientRect();
        }
        return { left: -9999, top: -9999 };
      },
      getCSSVars() {
        var t = getComputedStyle(this.DOM.scope, null);
        var e;
        this.CSSVars = {
          tagHideTransition: (({ value: t, unit: e }) =>
            "s" == e ? 1e3 * t : t)(
            (function (t) {
              if (!t) return {};
              var e = (t = t.trim().split(" ")[0])
                .split(/\d+/g)
                .filter((t) => t)
                .pop()
                .trim();
              return {
                value: +t
                  .split(e)
                  .filter((t) => t)[0]
                  .trim(),
                unit: e,
              };
            })(((e = "tag-hide-transition"), t.getPropertyValue("--" + e)))
          ),
        };
      },
      build(t) {
        var e = this.DOM;
        this.settings.mixMode.integrated
          ? ((e.originalInput = null), (e.scope = t), (e.input = t))
          : ((e.originalInput = t),
            (e.scope = this.parseTemplate("wrapper", [t, this.settings])),
            (e.input = e.scope.querySelector(
              this.settings.classNames.inputSelector
            )),
            t.parentNode.insertBefore(e.scope, t));
      },
      destroy() {
        this.events.unbindGlobal.call(this),
          this.DOM.scope.parentNode.removeChild(this.DOM.scope),
          this.dropdown.hide(!0),
          clearTimeout(this.dropdownHide__bindEventsTimeout);
      },
      loadOriginalValues(t) {
        var e,
          i = this.settings;
        if (((this.state.blockChangeEvent = !0), void 0 === t)) {
          const e = this.getPersistedData("value");
          t =
            e && !this.DOM.originalInput.value
              ? e
              : i.mixMode.integrated
              ? this.DOM.input.textContent
              : this.DOM.originalInput.value;
        }
        if ((this.removeAllTags(), t))
          if ("mix" == i.mode)
            this.parseMixTags(this.trim(t)),
              ((e = this.DOM.input.lastChild) && "BR" == e.tagName) ||
                this.DOM.input.insertAdjacentHTML("beforeend", "<br>");
          else {
            try {
              JSON.parse(t) instanceof Array && (t = JSON.parse(t));
            } catch (t) {}
            this.addTags(t).forEach(
              (t) => t && t.classList.add(i.classNames.tagNoAnimation)
            );
          }
        else this.postUpdate();
        (this.state.lastOriginalValueReported = i.mixMode.integrated
          ? ""
          : this.DOM.originalInput.value),
          (this.state.blockChangeEvent = !1);
      },
      cloneEvent(t) {
        var e = {};
        for (var i in t) e[i] = t[i];
        return e;
      },
      loading(t) {
        return (
          (this.state.isLoading = t),
          this.DOM.scope.classList[t ? "add" : "remove"](
            this.settings.classNames.scopeLoading
          ),
          this
        );
      },
      tagLoading(t, e) {
        return (
          t &&
            t.classList[e ? "add" : "remove"](
              this.settings.classNames.tagLoading
            ),
          this
        );
      },
      toggleClass(t, e) {
        "string" == typeof t && this.DOM.scope.classList.toggle(t, e);
      },
      toggleFocusClass(t) {
        this.toggleClass(this.settings.classNames.focus, !!t);
      },
      triggerChangeEvent: function () {
        if (!this.settings.mixMode.integrated) {
          var t = this.DOM.originalInput,
            e = this.state.lastOriginalValueReported !== t.value,
            i = new CustomEvent("change", { bubbles: !0 });
          e &&
            ((this.state.lastOriginalValueReported = t.value),
            (i.simulated = !0),
            t._valueTracker && t._valueTracker.setValue(Math.random()),
            t.dispatchEvent(i),
            this.trigger("change", this.state.lastOriginalValueReported),
            (t.value = this.state.lastOriginalValueReported));
        }
      },
      events: b,
      fixFirefoxLastTagNoCaret() {},
      placeCaretAfterNode(t) {
        if (t && t.parentNode) {
          var e = t.nextSibling,
            i = window.getSelection(),
            s = i.getRangeAt(0);
          i.rangeCount &&
            (s.setStartAfter(e || t),
            s.collapse(!0),
            i.removeAllRanges(),
            i.addRange(s));
        }
      },
      insertAfterTag(t, e) {
        if (
          ((e = e || this.settings.mixMode.insertAfterTag),
          t && t.parentNode && e)
        )
          return (
            (e = "string" == typeof e ? document.createTextNode(e) : e),
            t.parentNode.insertBefore(e, t.nextSibling),
            e
          );
      },
      editTag(t, e) {
        (t = t || this.getLastTag()), (e = e || {}), this.dropdown.hide();
        var i = this.settings;
        function s() {
          return t.querySelector(i.classNames.tagTextSelector);
        }
        var a = s(),
          n = this.getNodeIndex(t),
          o = this.tagData(t),
          r = this.events.callbacks,
          l = this,
          h = !0;
        if (a) {
          if (!(o instanceof Object && "editable" in o) || o.editable)
            return (
              a.setAttribute("contenteditable", !0),
              t.classList.add(i.classNames.tagEditing),
              this.tagData(t, {
                __originalData: d({}, o),
                __originalHTML: t.innerHTML,
              }),
              a.addEventListener("focus", r.onEditTagFocus.bind(this, t)),
              a.addEventListener("blur", function () {
                setTimeout(() => r.onEditTagBlur.call(l, s()));
              }),
              a.addEventListener("input", r.onEditTagInput.bind(this, a)),
              a.addEventListener("keydown", (e) =>
                r.onEditTagkeydown.call(this, e, t)
              ),
              a.focus(),
              this.setRangeAtStartEnd(!1, a),
              e.skipValidation || (h = this.editTagToggleValidity(t)),
              (a.originalIsValid = h),
              this.trigger("edit:start", {
                tag: t,
                index: n,
                data: o,
                isValid: h,
              }),
              this
            );
        } else
          console.warn(
            "Cannot find element in Tag template: .",
            i.classNames.tagTextSelector
          );
      },
      editTagToggleValidity(t, e) {
        var i;
        if ((e = e || this.tagData(t)))
          return (
            (i = !("__isValid" in e) || !0 === e.__isValid) ||
              this.removeTagsFromValue(t),
            this.update(),
            t.classList.toggle(this.settings.classNames.tagNotAllowed, !i),
            e.__isValid
          );
        console.warn("tag has no data: ", t, e);
      },
      onEditTagDone(t, e) {
        e = e || {};
        var i = {
          tag: (t = t || this.state.editing.scope),
          index: this.getNodeIndex(t),
          previousData: this.tagData(t),
          data: e,
        };
        this.trigger("edit:beforeUpdate", i, { cloneData: !1 }),
          (this.state.editing = !1),
          delete e.__originalData,
          delete e.__originalHTML,
          t && e[this.settings.tagTextProp]
            ? ((t = this.replaceTag(t, e)),
              this.editTagToggleValidity(t, e),
              this.settings.a11y.focusableTags
                ? t.focus()
                : this.placeCaretAfterNode(t.previousSibling))
            : t && this.removeTags(t),
          this.trigger("edit:updated", i),
          this.dropdown.hide(),
          this.settings.keepInvalidTags && this.reCheckInvalidTags();
      },
      replaceTag(t, e) {
        (e && e.value) || (e = t.__tagifyTagData),
          e.__isValid &&
            1 != e.__isValid &&
            d(e, this.getInvalidTagAttrs(e, e.__isValid));
        var i = this.createTagElem(e);
        return t.parentNode.replaceChild(i, t), this.updateValueByDOMTags(), i;
      },
      updateValueByDOMTags() {
        (this.value.length = 0),
          [].forEach.call(this.getTagElms(), (t) => {
            t.classList.contains(
              this.settings.classNames.tagNotAllowed.split(" ")[0]
            ) || this.value.push(this.tagData(t));
          }),
          this.update();
      },
      setRangeAtStartEnd(t, e) {
        (t = "number" == typeof t ? t : !!t),
          (e = (e = e || this.DOM.input).lastChild || e);
        var i = document.getSelection();
        try {
          i.rangeCount >= 1 &&
            ["Start", "End"].forEach((s) =>
              i.getRangeAt(0)["set" + s](e, t || e.length)
            );
        } catch (t) {}
      },
      injectAtCaret(t, e) {
        if ((e = e || this.state.selection.range))
          return (
            "string" == typeof t && (t = document.createTextNode(t)),
            e.deleteContents(),
            e.insertNode(t),
            this.setRangeAtStartEnd(!1, t),
            this.updateValueByDOMTags(),
            this.update(),
            this
          );
      },
      input: {
        set(t = "", e = !0) {
          var i = this.settings.dropdown.closeOnSelect;
          (this.state.inputText = t),
            e && (this.DOM.input.innerHTML = r("" + t)),
            !t && i && this.dropdown.hide.bind(this),
            this.input.autocomplete.suggest.call(this),
            this.input.validate.call(this);
        },
        raw() {
          return this.DOM.input.textContent;
        },
        validate() {
          var t =
            !this.state.inputText ||
            !0 === this.validateTag({ value: this.state.inputText });
          return (
            this.DOM.input.classList.toggle(
              this.settings.classNames.inputInvalid,
              !t
            ),
            t
          );
        },
        normalize(t) {
          var e = t || this.DOM.input,
            i = [];
          e.childNodes.forEach((t) => 3 == t.nodeType && i.push(t.nodeValue)),
            (i = i.join("\n"));
          try {
            i = i.replace(
              /(?:\r\n|\r|\n)/g,
              this.settings.delimiters.source.charAt(0)
            );
          } catch (t) {}
          return (
            (i = i.replace(/\s/g, " ")),
            this.settings.trim && (i = i.replace(/^\s+/, "")),
            i
          );
        },
        autocomplete: {
          suggest(t) {
            if (this.settings.autoComplete.enabled) {
              "string" == typeof (t = t || {}) && (t = { value: t });
              var e = t.value ? "" + t.value : "",
                i = e.substr(0, this.state.inputText.length).toLowerCase(),
                s = e.substring(this.state.inputText.length);
              e &&
              this.state.inputText &&
              i == this.state.inputText.toLowerCase()
                ? (this.DOM.input.setAttribute("data-suggest", s),
                  (this.state.inputSuggestion = t))
                : (this.DOM.input.removeAttribute("data-suggest"),
                  delete this.state.inputSuggestion);
            }
          },
          set(t) {
            var e = this.DOM.input.getAttribute("data-suggest"),
              i = t || (e ? this.state.inputText + e : null);
            return (
              !!i &&
              ("mix" == this.settings.mode
                ? this.replaceTextWithNode(
                    document.createTextNode(this.state.tag.prefix + i)
                  )
                : (this.input.set.call(this, i), this.setRangeAtStartEnd()),
              this.input.autocomplete.suggest.call(this),
              this.dropdown.hide(),
              !0)
            );
          },
        },
      },
      getTagIdx(t) {
        return this.value.findIndex((e) => e.__tagId == (t || {}).__tagId);
      },
      getNodeIndex(t) {
        var e = 0;
        if (t) for (; (t = t.previousElementSibling); ) e++;
        return e;
      },
      getTagElms(...t) {
        var e =
          "." + [...this.settings.classNames.tag.split(" "), ...t].join(".");
        return [].slice.call(this.DOM.scope.querySelectorAll(e));
      },
      getLastTag() {
        var t = this.DOM.scope.querySelectorAll(
          `${this.settings.classNames.tagSelector}:not(.${this.settings.classNames.tagHide}):not([readonly])`
        );
        return t[t.length - 1];
      },
      tagData: (t, e, i) =>
        t
          ? (e &&
              (t.__tagifyTagData = i ? e : d({}, t.__tagifyTagData || {}, e)),
            t.__tagifyTagData)
          : (console.warn("tag element doesn't exist", t, e), e),
      isTagDuplicate(t, e) {
        var i = this.settings;
        return (
          "select" != i.mode &&
          this.value.reduce(
            (a, n) =>
              s(this.trim("" + t), n.value, e || i.dropdown.caseSensitive)
                ? a + 1
                : a,
            0
          )
        );
      },
      getTagIndexByValue(t) {
        var e = [];
        return (
          this.getTagElms().forEach((i, a) => {
            s(
              this.trim(i.textContent),
              t,
              this.settings.dropdown.caseSensitive
            ) && e.push(a);
          }),
          e
        );
      },
      getTagElmByValue(t) {
        var e = this.getTagIndexByValue(t)[0];
        return this.getTagElms()[e];
      },
      flashTag(t) {
        t &&
          (t.classList.add(this.settings.classNames.tagFlash),
          setTimeout(() => {
            t.classList.remove(this.settings.classNames.tagFlash);
          }, 100));
      },
      isTagBlacklisted(t) {
        return (
          (t = this.trim(t.toLowerCase())),
          this.settings.blacklist.filter((e) => ("" + e).toLowerCase() == t)
            .length
        );
      },
      isTagWhitelisted(t) {
        return !!this.getWhitelistItem(t);
      },
      getWhitelistItem(t, e, i) {
        e = e || "value";
        var a,
          n = this.settings;
        return (
          (i = i || n.whitelist).some((i) => {
            var o = "string" == typeof i ? i : i[e] || i.value;
            if (s(o, t, n.dropdown.caseSensitive, n.trim))
              return (a = "string" == typeof i ? { value: i } : i), !0;
          }),
          a ||
            "value" != e ||
            "value" == n.tagTextProp ||
            (a = this.getWhitelistItem(t, n.tagTextProp, i)),
          a
        );
      },
      validateTag(t) {
        var e = this.settings,
          i = "value" in t ? "value" : e.tagTextProp,
          s = this.trim(t[i] + "");
        return (t[i] + "").trim()
          ? e.pattern && e.pattern instanceof RegExp && !e.pattern.test(s)
            ? this.TEXTS.pattern
            : !e.duplicates && this.isTagDuplicate(s, this.state.editing)
            ? this.TEXTS.duplicate
            : this.isTagBlacklisted(s) ||
              (e.enforceWhitelist && !this.isTagWhitelisted(s))
            ? this.TEXTS.notAllowed
            : !e.validate || e.validate(t)
          : this.TEXTS.empty;
      },
      getInvalidTagAttrs(t, e) {
        return {
          "aria-invalid": !0,
          class: `${t.class || ""} ${
            this.settings.classNames.tagNotAllowed
          }`.trim(),
          title: e,
        };
      },
      hasMaxTags() {
        return this.value.length >= this.settings.maxTags && this.TEXTS.exceed;
      },
      setReadonly(t, e) {
        var i = this.settings;
        document.activeElement.blur(),
          (i[e || "readonly"] = t),
          this.DOM.scope[(t ? "set" : "remove") + "Attribute"](
            e || "readonly",
            !0
          ),
          "mix" == i.mode && this.setContentEditable(!t);
      },
      setContentEditable(t) {
        !this.settings.readonly &&
          this.settings.userInput &&
          (this.DOM.input.contentEditable = t);
      },
      setDisabled(t) {
        this.setReadonly(t, "disabled");
      },
      normalizeTags(t) {
        var e = this.settings,
          i = e.whitelist,
          s = e.delimiters,
          a = e.mode,
          n = e.tagTextProp;
        e.enforceWhitelist;
        var o = [],
          r = !!i && i[0] instanceof Object,
          l = t instanceof Array,
          d = (t) =>
            (t + "")
              .split(s)
              .filter((t) => t)
              .map((t) => ({ [n]: this.trim(t), value: this.trim(t) }));
        if (
          ("number" == typeof t && (t = t.toString()), "string" == typeof t)
        ) {
          if (!t.trim()) return [];
          t = d(t);
        } else l && (t = [].concat(...t.map((t) => (t.value ? t : d(t)))));
        return (
          r &&
            (t.forEach((t) => {
              var e = o.map((t) => t.value),
                i = this.dropdown.filterListItems.call(this, t[n], {
                  exact: !0,
                });
              this.settings.duplicates ||
                (i = i.filter((t) => !e.includes(t.value)));
              var s = i.length > 1 ? this.getWhitelistItem(t[n], n, i) : i[0];
              s && s instanceof Object
                ? o.push(s)
                : "mix" != a &&
                  (null == t.value && (t.value = t[n]), o.push(t));
            }),
            o.length && (t = o)),
          t
        );
      },
      parseMixTags(t) {
        var e = this.settings,
          i = e.mixTagsInterpolator,
          s = e.duplicates,
          a = e.transformTag,
          n = e.enforceWhitelist,
          o = e.maxTags,
          r = e.tagTextProp,
          l = [];
        return (
          (t = t
            .split(i[0])
            .map((t, e) => {
              var d,
                h,
                g,
                c = t.split(i[1]),
                p = c[0],
                u = l.length == o;
              try {
                if (p == +p) throw Error;
                h = JSON.parse(p);
              } catch (t) {
                h = this.normalizeTags(p)[0] || { value: p };
              }
              if (
                (a.call(this, h),
                u ||
                  !(c.length > 1) ||
                  (n && !this.isTagWhitelisted(h.value)) ||
                  (!s && this.isTagDuplicate(h.value)))
              ) {
                if (t) return e ? i[0] + t : t;
              } else
                (h[(d = h[r] ? r : "value")] = this.trim(h[d])),
                  (g = this.createTagElem(h)),
                  l.push(h),
                  g.classList.add(this.settings.classNames.tagNoAnimation),
                  (c[0] = g.outerHTML),
                  this.value.push(h);
              return c.join("");
            })
            .join("")),
          (this.DOM.input.innerHTML = t),
          this.DOM.input.appendChild(document.createTextNode("")),
          this.DOM.input.normalize(),
          this.getTagElms().forEach((t, e) => this.tagData(t, l[e])),
          this.update({ withoutChangeEvent: !0 }),
          t
        );
      },
      replaceTextWithNode(t, e) {
        if (this.state.tag || e) {
          e = e || this.state.tag.prefix + this.state.tag.value;
          var i,
            s,
            a = window.getSelection(),
            n = a.anchorNode,
            o = this.state.tag.delimiters
              ? this.state.tag.delimiters.length
              : 0;
          return (
            n.splitText(a.anchorOffset - o),
            -1 == (i = n.nodeValue.lastIndexOf(e))
              ? !0
              : ((s = n.splitText(i)), t && n.parentNode.replaceChild(t, s), !0)
          );
        }
      },
      selectTag(t, e) {
        var i = this.settings;
        if (!i.enforceWhitelist || this.isTagWhitelisted(e.value)) {
          this.input.set.call(this, e[i.tagTextProp] || e.value, !0),
            this.state.actions.selectOption &&
              setTimeout(this.setRangeAtStartEnd.bind(this));
          var s = this.getLastTag();
          return (
            s ? this.replaceTag(s, e) : this.appendTag(t),
            i.enforceWhitelist && this.setContentEditable(!1),
            (this.value[0] = e),
            this.update(),
            this.trigger("add", { tag: t, data: e }),
            [t]
          );
        }
      },
      addEmptyTag(t) {
        var e = d({ value: "" }, t || {}),
          i = this.createTagElem(e);
        this.tagData(i, e),
          this.appendTag(i),
          this.editTag(i, { skipValidation: !0 });
      },
      addTags(t, e, i) {
        var s = [],
          a = this.settings,
          n = document.createDocumentFragment();
        return (
          (i = i || a.skipInvalid),
          t && 0 != t.length
            ? ((t = this.normalizeTags(t)),
              "mix" == a.mode
                ? this.addMixTags(t)
                : ("select" == a.mode && (e = !1),
                  this.DOM.input.removeAttribute("style"),
                  t.forEach((t) => {
                    var e,
                      o = {},
                      r = Object.assign({}, t, { value: t.value + "" });
                    if (
                      ((t = Object.assign({}, r)),
                      a.transformTag.call(this, t),
                      (t.__isValid = this.hasMaxTags() || this.validateTag(t)),
                      !0 !== t.__isValid)
                    ) {
                      if (i) return;
                      d(o, this.getInvalidTagAttrs(t, t.__isValid), {
                        __preInvalidData: r,
                      }),
                        t.__isValid == this.TEXTS.duplicate &&
                          this.flashTag(this.getTagElmByValue(t.value));
                    }
                    if (
                      ("readonly" in t &&
                        (t.readonly
                          ? (o["aria-readonly"] = !0)
                          : delete t.readonly),
                      (e = this.createTagElem(t, o)),
                      s.push(e),
                      "select" == a.mode)
                    )
                      return this.selectTag(e, t);
                    n.appendChild(e),
                      t.__isValid && !0 === t.__isValid
                        ? (this.value.push(t),
                          this.trigger("add", {
                            tag: e,
                            index: this.value.length - 1,
                            data: t,
                          }))
                        : (this.trigger("invalid", {
                            data: t,
                            index: this.value.length,
                            tag: e,
                            message: t.__isValid,
                          }),
                          a.keepInvalidTags ||
                            setTimeout(() => this.removeTags(e, !0), 1e3)),
                      this.dropdown.position();
                  }),
                  this.appendTag(n),
                  this.update(),
                  t.length && e && this.input.set.call(this),
                  this.dropdown.refilter(),
                  s))
            : ("select" == a.mode && this.removeAllTags(), s)
        );
      },
      addMixTags(t) {
        if ((t = this.normalizeTags(t))[0].prefix || this.state.tag)
          return this.prefixedTextToTag(t[0]);
        "string" == typeof t && (t = [{ value: t }]);
        var e = !!this.state.selection,
          i = document.createDocumentFragment();
        return (
          t.forEach((t) => {
            var e = this.createTagElem(t);
            i.appendChild(e), this.insertAfterTag(e);
          }),
          e
            ? this.injectAtCaret(i)
            : (this.DOM.input.focus(),
              (e = this.setStateSelection()).range.setStart(
                this.DOM.input,
                e.range.endOffset
              ),
              e.range.setEnd(this.DOM.input, e.range.endOffset),
              this.DOM.input.appendChild(i),
              this.updateValueByDOMTags(),
              this.update()),
          i
        );
      },
      prefixedTextToTag(t) {
        var e,
          i = this.settings,
          s = this.state.tag.delimiters;
        if (
          (i.transformTag.call(this, t),
          (t.prefix =
            t.prefix || this.state.tag
              ? this.state.tag.prefix
              : (i.pattern.source || i.pattern)[0]),
          (e = this.createTagElem(t)),
          this.replaceTextWithNode(e) || this.DOM.input.appendChild(e),
          setTimeout(
            () => e.classList.add(this.settings.classNames.tagNoAnimation),
            300
          ),
          this.value.push(t),
          this.update(),
          !s)
        ) {
          var a = this.insertAfterTag(e) || e;
          this.placeCaretAfterNode(a);
        }
        return (
          (this.state.tag = null),
          this.trigger("add", d({}, { tag: e }, { data: t })),
          e
        );
      },
      appendTag(t) {
        var e = this.DOM,
          i = e.scope.lastElementChild;
        i === e.input ? e.scope.insertBefore(t, i) : e.scope.appendChild(t);
      },
      createTagElem(t, i) {
        t.__tagId = ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(
          /[018]/g,
          (t) =>
            (
              t ^
              (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (t / 4)))
            ).toString(16)
        );
        var s,
          a = d({}, t, e({ value: r(t.value + "") }, i));
        return (
          (function (t) {
            for (
              var e,
                i = document.createNodeIterator(
                  t,
                  NodeFilter.SHOW_TEXT,
                  null,
                  !1
                );
              (e = i.nextNode());

            )
              e.textContent.trim() || e.parentNode.removeChild(e);
          })((s = this.parseTemplate("tag", [a]))),
          this.tagData(s, t),
          s
        );
      },
      reCheckInvalidTags() {
        var t = this.settings;
        this.getTagElms(t.classNames.tagNotAllowed).forEach((t, e) => {
          var i = this.tagData(t),
            s = this.hasMaxTags(),
            a = this.validateTag(i);
          if (!0 === a && !s)
            return (
              (i = i.__preInvalidData
                ? i.__preInvalidData
                : { value: i.value }),
              this.replaceTag(t, i)
            );
          t.title = s || a;
        });
      },
      removeTags(t, e, i) {
        var s;
        if (
          ((t =
            t && t instanceof HTMLElement
              ? [t]
              : t instanceof Array
              ? t
              : t
              ? [t]
              : [this.getLastTag()]),
          (s = t.reduce((t, e) => {
            e && "string" == typeof e && (e = this.getTagElmByValue(e));
            var i = this.tagData(e);
            return (
              e &&
                i &&
                !i.readonly &&
                t.push({
                  node: e,
                  idx: this.getTagIdx(i),
                  data: this.tagData(e, { __removed: !0 }),
                }),
              t
            );
          }, [])),
          (i = "number" == typeof i ? i : this.CSSVars.tagHideTransition),
          "select" == this.settings.mode &&
            ((i = 0), this.input.set.call(this)),
          1 == s.length &&
            s[0].node.classList.contains(
              this.settings.classNames.tagNotAllowed
            ) &&
            (e = !0),
          s.length)
        )
          return this.settings.hooks
            .beforeRemoveTag(s, { tagify: this })
            .then(() => {
              function t(t) {
                t.node.parentNode &&
                  (t.node.parentNode.removeChild(t.node),
                  e
                    ? this.settings.keepInvalidTags &&
                      this.trigger("remove", { tag: t.node, index: t.idx })
                    : (this.trigger("remove", {
                        tag: t.node,
                        index: t.idx,
                        data: t.data,
                      }),
                      this.dropdown.refilter(),
                      this.dropdown.position(),
                      this.DOM.input.normalize(),
                      this.settings.keepInvalidTags &&
                        this.reCheckInvalidTags()));
              }
              i && i > 10 && 1 == s.length
                ? function (e) {
                    (e.node.style.width =
                      parseFloat(window.getComputedStyle(e.node).width) + "px"),
                      document.body.clientTop,
                      e.node.classList.add(this.settings.classNames.tagHide),
                      setTimeout(t.bind(this), i, e);
                  }.call(this, s[0])
                : s.forEach(t.bind(this)),
                e ||
                  (this.removeTagsFromValue(s.map((t) => t.node)),
                  this.update(),
                  "select" == this.settings.mode &&
                    this.setContentEditable(!0));
            })
            .catch((t) => {});
      },
      removeTagsFromDOM() {
        [].slice
          .call(this.getTagElms())
          .forEach((t) => t.parentNode.removeChild(t));
      },
      removeTagsFromValue(t) {
        (t = Array.isArray(t) ? t : [t]).forEach((t) => {
          var e = this.tagData(t),
            i = this.getTagIdx(e);
          i > -1 && this.value.splice(i, 1);
        });
      },
      removeAllTags(t) {
        (t = t || {}),
          (this.value = []),
          "mix" == this.settings.mode
            ? (this.DOM.input.innerHTML = "")
            : this.removeTagsFromDOM(),
          this.dropdown.position(),
          "select" == this.settings.mode &&
            (this.input.set.call(this), this.setContentEditable(!0)),
          this.update(t);
      },
      postUpdate() {
        var t = this.settings.classNames,
          e =
            "mix" == this.settings.mode
              ? this.settings.mixMode.integrated
                ? this.DOM.input.textContent
                : this.DOM.originalInput.value.trim()
              : this.value.length + this.input.raw.call(this).length;
        this.toggleClass(
          t.hasMaxTags,
          this.value.length >= this.settings.maxTags
        ),
          this.toggleClass(t.hasNoTags, !this.value.length),
          this.toggleClass(t.empty, !e);
      },
      setOriginalInputValue(t) {
        var e = this.DOM.originalInput;
        this.settings.mixMode.integrated ||
          ((e.value = t),
          (e.tagifyValue = e.value),
          this.setPersistedData(t, "value"));
      },
      update(t) {
        var e = this.getInputValue();
        this.setOriginalInputValue(e),
          this.postUpdate(),
          (t || {}).withoutChangeEvent ||
            this.state.blockChangeEvent ||
            this.triggerChangeEvent();
      },
      getInputValue() {
        var t = this.getCleanValue();
        return "mix" == this.settings.mode
          ? this.getMixedTagsAsString(t)
          : t.length
          ? this.settings.originalInputValueFormat
            ? this.settings.originalInputValueFormat(t)
            : JSON.stringify(t)
          : "";
      },
      getCleanValue(t) {
        return (
          (e = t || this.value),
          (i = this.dataProps),
          e && Array.isArray(e) && e.map((t) => a(t, i))
        );
        var e, i;
      },
      getMixedTagsAsString() {
        var t = "",
          e = this,
          i = this.settings.mixTagsInterpolator;
        return (
          (function s(n) {
            n.childNodes.forEach((n) => {
              if (1 == n.nodeType) {
                const o = e.tagData(n);
                if (
                  ("BR" == n.tagName && (t += "\r\n"),
                  "DIV" == n.tagName || "P" == n.tagName)
                )
                  (t += "\r\n"), s(n);
                else if (c.call(e, n) && o) {
                  if (o.__removed) return;
                  t += i[0] + JSON.stringify(a(o, e.dataProps)) + i[1];
                }
              } else t += n.textContent;
            });
          })(this.DOM.input),
          t
        );
      },
    }),
    (y.prototype.removeTag = y.prototype.removeTags),
    y
  );
});
