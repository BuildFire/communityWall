const errorsList = {
    ERROR_400: "Malformatted Data",
    ERROR_401: "Not Authenticated",
    ERROR_404: "No Data Found",
    ERROR_402:"Not Authorized"
}




