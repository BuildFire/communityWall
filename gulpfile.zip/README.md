# socialPlugin ![](https://api.travis-ci.org/BuildFire/socialPlugin.svg)
Social wall

To pass a spcific Wall ID and Title to load make sure you navigate to this plugin using
````
 buildfire.navigation.navigateTo(
  ...pluginInstanceData
  ,queryString: 'wid=' + wid + "&wTitle=" + title 
 )
 ````
